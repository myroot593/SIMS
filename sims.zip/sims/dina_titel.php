<?php
include "config/koneksi.php";
if (isset($_GET['module'])){
$module=$_GET['module'];
		echo "$module";
}
else{
		echo "ROOT93.CO.ID";
}

?>