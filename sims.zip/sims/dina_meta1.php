<?php
		echo ".::ROOT93.CO.ID::.";
?>
