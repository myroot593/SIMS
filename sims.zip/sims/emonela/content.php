<?php
include "../config/koneksi.php";
include "../config/library.php";
include "../config/fungsi_indotgl.php";
include "../config/fungsi_combobox.php";
include "../config/class_paging.php";
include "../config/fungsi_rupiah.php";

// Bagian Home
if ($_GET['module']=='home'){
  if ($_SESSION['level']=='admin' or 'user'){
  echo "<h2>Selamat Datang</h2>
          <p><b>$_SESSION[nama]</b>, selamat datang di Aplikasi e-Monitoring, Evaluasi dan Pelaporan <b>(e-Monela)</b> Bappeda Kabupaten Pangandaran.<br> </p>
<p align=justify>Penerapan PP 39/2006 tentang Tata Cara Pengendalian dan Evaluasi Pelaksanaan Rencana Pembangunan merupakan upaya untuk menjawab dan memenuhi tantangan dan kebutuhan dalam rangka melaksanakan siklus manajemen pembangunan secara utuh. Tersedianya sistem monitoring dan evaluasi (monev) yang handal akan memberikan kontribusi nyata guna berjalannya siklus umpan balik pada tahap perencanaan yang pada ahirnya akan meningkatkan kualitas perencanaan pembangunan.</p>
<p align=justify>Sistem monev kinerja pembangunan, khususnya terhadap program dan kegiatan yang dituangkan dalam dokumen perencanaan, perlu terus dikembangkan agar lebih bermanfaat bagi manajemen pembangunan. Penyempurnaan mekanisme dan pelaporan monev, secara langsung mengharuskan terpenuhinya dokumen perencanaan yang berkualitas dan dapat dievaluasi.</p>
<p align=justify>Pembangunan aplikasi monev berbasis website (e-Monela) merupakan upaya untuk mengefektifkan dan mengefisienkan pelaporan menuju pada peningkatan kualitas dengan melakukan penyederhanaan terhadap format, aplikasi dan mekanisme pelaporan monev kinerja pembangunan.</p>
<p align=justify>Aplikasi e-Monela yang dikembangkan saat ini telah memuat informasi kinerja yang dibutuhkan sebagai masukan dalam rangka penerapan Perencanaan dan Penganggaran Berbasis Kinerja (Performance-Based-Planning and Budgeting), serta lebih lanjut untuk mengetahui kontribusi kegiatan/program terhadap pencapaian target Prioritas Kabupaten, Provinsi dan Nasional.</p>
		  <p>Silahkan klik menu pilihan yang berada di sebelah kiri untuk mengakses konten website. </p>
          <p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
          <p align=right>Login : $hari_ini, ";
  echo tgl_indo(date("Y m d")); 
  echo " | ";
  echo date("H:i:s");
  echo " WIB</p>";
  }
}

// Bagian Modul
elseif ($_GET['module']=='modul'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_modul/modul.php";
  }
}

// Bagian SKPD
elseif ($_GET['module']=='skpd'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_skpd/skpd.php";
  }
}

// Bagian Program
elseif ($_GET['module']=='program'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_program/program.php";
  }
}

// Bagian Kegiatan
elseif ($_GET['module']=='kegiatan'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_kegiatan/kegiatan.php";
  }
}

// Bagian Urusan
elseif ($_GET['module']=='urusan'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_urusan/urusan.php";
  }
}

// Bagian SPT
elseif ($_GET['module']=='data_skpd'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_data_skpd/data_skpd.php";
  }
}

// Bagian Kegiatan SKPD
elseif ($_GET['module']=='kegiatan_skpd'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_kegiatan_skpd/kegiatan_skpd.php";
  }
}

// Bagian Order
elseif ($_GET['module']=='berita'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_berita/berita.php";
  }
}

// Bagian Order
elseif ($_GET['module']=='agenda'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_agenda/agenda.php";
  }
}

// Bagian Pesan
elseif ($_GET['module']=='pesan'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_pesan/pesan.php";
  }
}

// Bagian Member
elseif ($_GET['module']=='user'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_user/user.php";
  }
}

// Bagian Profil
elseif ($_GET['module']=='profil'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_profil/profil.php";
  }
}

// Bagian Hubungi
elseif ($_GET['module']=='hubungi'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_hubungi/hubungi.php";
  }
}

// Modul Monitoring Anggaran
elseif ($_GET['module']=='mon_anggaran'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_mon_anggaran/mon_anggaran.php";
  }
}

// Modul Monitoring Fisik
elseif ($_GET['module']=='mon_fisik'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_mon_fisik/mon_fisik.php";
  }
}

// Bagian Menu Utama
elseif ($_GET['module']=='menuutama'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_menuutama/menuutama.php";
  }
}


// Bagian Sub Menu
elseif ($_GET['module']=='submenu'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_submenu/submenu.php";
  }
}

// Bagian Password
elseif ($_GET['module']=='password'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_password/password.php";
  }
}

// Bagian Laporan
elseif ($_GET['module']=='laporan'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_laporan/laporan.php";
  }
}

// Bagian Laporan
elseif ($_GET['module']=='laporan2'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_laporan2/laporan2.php";
  }
}

// Apabila modul tidak ditemukan
else{
  echo "<p><b>MODUL BELUM ADA ATAU BELUM LENGKAP</b></p>";
}
?>
