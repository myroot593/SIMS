<?php
include "config/koneksi.php";
$sekilas=mysqli_query($connect,"SELECT * FROM agenda ORDER BY id_agenda DESC LIMIT 3");
$sek=mysqli_num_rows($sekilas);

if ($sek > 0){
echo "<div class='category'>";
  echo "<div class='small_heading'>
        </div><ul>";
  while($s=mysqli_fetch_array($sekilas)){
  $tl=tgl_indo($s['tanggal']);
   echo "<li><span class='news-text'>$s[judul] - $tl</span></li>";
  }
  echo "</ul><div class='clear'></div></div>";
}

?>
