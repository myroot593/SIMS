<?php
session_start();
error_reporting(0);
include "config/koneksi.php";
include "config/library.php";

$module=$_GET['module'];
$act=$_GET['act'];

if ($module=='keranjang' AND $act=='tambah'){
	if (empty($_SESSION['namauser']) AND empty($_SESSION['passuser'])){
	echo"<script>alert('Untuk melakukan transaksi silakan daftar atau login terlebih dahulu.'); window.location = 'daftar.html'
	</script>"; }
	else {
	$sid = session_id();
	$sql2 = mysqli_query($connect,"SELECT stok FROM produk WHERE id_produk='$_GET[id]'");
	$r=mysqli_fetch_array($sql2);
	$stok=$r[stok];
  
  if ($stok == 0){
      echo "stok habis";
  }
  else{
	// check if the product is already
	// in cart table for this session
	$sql = mysqli_query($connect,"SELECT id_produk FROM orders_temp
			WHERE id_produk='$_GET[id]' AND id_session='$sid'");
	$ketemu=mysqli_num_rows($sql);
	if ($ketemu==0){
		// put the product in cart table
		mysqli_query($connect,"INSERT INTO orders_temp (id_produk, jumlah, id_session, tgl_order_temp, jam_order_temp, stok_temp)
				VALUES ('$_GET[id]', 1, '$sid', '$tgl_sekarang', '$jam_sekarang', '$stok')");
	} else {
		// update product quantity in cart table
		mysqli_query($connect,"UPDATE orders_temp 
		        SET jumlah = jumlah + 1
				WHERE id_session ='$sid' AND id_produk='$_GET[id]'");		
	}	
	deleteAbandonedCart();
	header('Location:keranjang-belanja.html');
  }				
}
}

elseif ($module=='keranjang' AND $act=='hapus'){
	mysqli_query($connect,"DELETE FROM orders_temp WHERE id_orders_temp='$_GET[id]'");
	header('Location:keranjang-belanja.html');				
}

elseif ($module=='keranjang' AND $act=='update'){
  $id       = $_POST[id];
  $jml_data = count($id);
  $jumlah   = $_POST[jml]; // quantity
  for ($i=1; $i <= $jml_data; $i++){
	$sql2 = mysqli_query($connect,"SELECT stok_temp FROM orders_temp	WHERE id_orders_temp='".$id[$i]."'");
	while($r=mysqli_fetch_array($sql2)){
if ($jumlah[$i] > $r[stok_temp]){
echo "<script>window.alert('Jumlah yang dibeli melebihi stok yang ada');
window.location=('keranjang-belanja.html')</script>";
}
elseif($jumlah[$i] == 0){
echo "<script>window.alert('Anda tidak boleh menginputkan angka 0 atau mengkosongkannya!');
window.location=('keranjang-belanja.html')</script>";
} // tambahan update ada disini
else{
mysqli_query($connect,"UPDATE orders_temp SET jumlah = '".$jumlah[$i]."'
WHERE id_orders_temp = '".$id[$i]."'");
header('Location:keranjang-belanja.html');
    }
  }
  }
}

// simpan member
elseif ($module=='user' AND $act=='simpan'){
$kar1=strstr($_POST[email], "@");
$kar2=strstr($_POST[email], ".");

// Cek email kustomer di database
$cek_email=mysqli_num_rows(mysqli_query($connect,"SELECT email FROM member WHERE email='$_POST[email]'"));
// Kalau email sudah ada yang pakai
if ($cek_email > 0){
echo "<script>window.alert('Email yang anda masukkan sudah digunakan')</script>";
 echo "<meta http-equiv='refresh' content='0; url=daftar.html'>";
}
elseif (empty($_POST[nama]) || empty($_POST[password]) || empty($_POST[alamat]) || empty($_POST[telpon]) || empty($_POST[email]) || empty($_POST[kode])){
  echo "<script>window.alert('Data yang anda isikan belum lengkap ')</script>";
 echo "<meta http-equiv='refresh' content='0; url=daftar.html'>";
}
elseif (!ereg("[a-z|A-Z]","$_POST[nama]")){
	echo "<script>window.alert('Nama tidak boleh diisi dengan angka atau simbol')</script>";
 echo "<meta http-equiv='refresh' content='0; url=daftar.html'>";

}
elseif (strlen($kar1)==0 OR strlen($kar2)==0){
	 echo "<script>window.alert('Alamat email Anda tidak valid, mungkin kurang tanda titik (.) atau tanda @.')</script>";
 echo "<meta http-equiv='refresh' content='0; url=daftar.html'>";
}
else{

if(!empty($_POST['kode'])){
  if($_POST['kode']==$_SESSION['captcha_session']){

function antiinjection($data){
  $filter_sql = mysqli_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter_sql;
}

$nama   = antiinjection($_POST['nama']);
$alamat = antiinjection($_POST['alamat']);
$telpon = antiinjection($_POST['telpon']);
$email = antiinjection($_POST['email']);
$password=md5($_POST['password']);

// simpan data member 
mysqli_query($connect,"INSERT INTO member(nama_lengkap, password, alamat, no_telp, email) 
             VALUES('$nama','$password','$alamat','$telpon','$email')");
 echo "<script>window.alert('Pendaftaran Berhasil, Klik OK untuk melanjutkan')</script>";
 echo "<meta http-equiv='refresh' content='0; url=store'>";
} } } }

// Update user
elseif ($module=='user' AND $act=='edit'){
	if(!empty($_POST['kode'])){
	if($_POST['kode']==$_SESSION['captcha_session']){
	
	if(empty($_POST['password'])) {
  mysqli_query($connect,"UPDATE member SET nama_lengkap='$_POST[nama]',alamat='$_POST[alamat]',
                                no_telp='$_POST[telpon]',email='$_POST[email]' WHERE 
								id_member='$_POST[id]'");
								}
	else {
	$pass=md5($_POST['password']);
  mysqli_query($connect,"UPDATE member SET nama_lengkap='$_POST[nama]',password='$pass',alamat='$_POST[alamat]',
                                no_telp='$_POST[telpon]',email='$_POST[email]' WHERE 
								id_member='$_POST[id]'");
								}
		echo"<script>alert('Profil Anda berhasil dirubah.'); window.location = 'store'</script>";
		}else{
			echo "<span class='table8'>Kode yang Anda masukkan tidak cocok<br />
			      <a href=javascript:history.go(-1)><b>Ulangi Lagi</b></a>";
		}
	}else{
		echo "<span class='table8'>Anda belum memasukkan kode<br />
  	      <a href=javascript:history.go(-1)><b>Ulangi Lagi</b></a>";
	}
}

// Lupa Password
elseif ($module=='forget'){
  $sql    = "SELECT password FROM member WHERE email='$_POST[email]'";
  $hasil  = mysqli_query($connect,$sql);
  $jumlah = mysqli_num_rows($hasil);

  if ($jumlah==1){
    $data=mysqli_fetch_array($hasil);
	$pass=md5($data['password']);
    $kepada = "$_POST[email]"; //alamat email user
    $judul = "Password Anda";
    $dari = "From: email@namadomain.com \r\n"; 
    $dari .= "Content-type: text/html \r\n";
    $pesan = "Password Anda untuk login ke website kami <br>";
    $pesan .= "Password Anda : <b>$pass</b>";

    mail($kepada,$judul,$pesan,$dari);
    echo "<script>alert('Password telah terkirim ke email Anda.'); window.location = 'store'</script>";
  }
else{
    echo "<script>alert('Email yang Anda masukkan tidak terdaftar dalam database Kami.'); window.location = 'store'</script>";
  }
}

function deleteAbandonedCart(){
	$kemarin = date('Y-m-d', mktime(0,0,0, date('m'), date('d') - 1, date('Y')));
	mysqli_query($connect,"DELETE FROM orders_temp 
	        WHERE tgl_order_temp < '$kemarin'");
}


?>
