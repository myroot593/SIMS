<?php
  session_start();
  unset($_SESSION['user']); 
  unset($_SESSION['nama']); 
  unset($_SESSION['pass']);  
  unset($_SESSION['level']);
  session_destroy();
  echo "<script>alert('Anda menuju halaman web'); window.location = '../index.php'</script>";
?>