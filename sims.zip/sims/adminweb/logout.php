<?php
  session_start();
  unset($_SESSION['user']); 
  unset($_SESSION['nama']); 
  unset($_SESSION['pass']);  
  unset($_SESSION['level']);
  session_destroy();
  echo "<script>alert('Anda telah keluar dari halaman administrator'); window.location = 'index.php'</script>";
?>