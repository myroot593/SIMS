<?php
if(isset($_POST['btnSiswa'])){
//hitung jumlah form yang dikirim
$jumlah = count($_POST['nim']);

echo "<h1>Cetak semua form</h1>";
for($i=0; $i<$jumlah; $i++){
$urut = $i+1;
$nim = $_POST['nim'][$i];
$nama = $_POST['nama'][$i];
//jika mau dimasukkan ke databases, silahkan buat query anda disini
echo $urut." ".$nim ." ".$nama."<br />";
}

echo "<h1>Khusus NIM dan Nama yang tidak kosong</h1>";
//jika hanya akan memproses data yang nim dan namanya tidak kosong
for($a=0; $a<$jumlah; $a++){
$urut = $a+1;
$nim = $_POST['nim'][$a];
$nama = $_POST['nama'][$a];
if(trim($nim) !="" and trim($nama) !=""){
//jika mau dimasukkan ke databases, silahkan buat query anda disini
echo $urut." ".$nim ." ".$nama."<br />";
}
}
}
?>


<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus SPT
if ($module=='spt' AND $act=='hapusspt'){
  mysql_query("DELETE FROM spt WHERE id_spt='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input SPT
elseif ($module=='spt' AND $act=='inputspt'){
    mysql_query("INSERT INTO spt (nomor_spt,
                                    tgl_spt,
                                    dasar,
                                    uraian,
                                    tgl_mulai,
									tgl_selesai,
									waktu,
									tempat,
									petugas,
									pengikut1,
									pengikut2,
									pengikut3,
									pengikut4,
									pengikut5,
									pengikut6) 
                            VALUES('$_POST[nomor]',
                                   '$_POST[tgl_spt]',
                                   '$_POST[dasar]',
                                   '$_POST[uraian]',
								   '$_POST[tgl_mulai]',
								   '$_POST[tgl_selesai]',
								   '$_POST[waktu]',
								   '$_POST[tempat]',
								   '$_POST[petugas]',
								   '$_POST[pengikut1]',
								   '$_POST[pengikut2]',
								   '$_POST[pengikut3]',
								   '$_POST[pengikut4]',
								   '$_POST[pengikut5]',
								   '$_POST[pengikut6]')");
  header('location:../../media.php?module='.$module);
}

elseif ($module=='spt' AND $act=='update'){
 mysql_query("UPDATE spt SET nomor_spt 	   = '$_POST[nomor]',
                                   tgl_spt		 = '$_POST[tgl_spt]',
                                   dasar         = '$_POST[dasar]',
								   uraian        = '$_POST[uraian]',
                                   tgl_mulai     = '$_POST[tgl_mulai]',
								   tgl_selesai   = '$_POST[tgl_selesai]',
								   waktu    	 = '$_POST[waktu]',
								   tempat     	 = '$_POST[tempat]',
								   petugas     	 = '$_POST[petugas]',
								   pengikut1     = '$_POST[pengikut1]',
								   pengikut2     = '$_POST[pengikut2]',
								   pengikut3     = '$_POST[pengikut3]',
								   pengikut4     = '$_POST[pengikut4]',
								   pengikut5     = '$_POST[pengikut5]',
								   pengikut6     = '$_POST[pengikut6]'
                             WHERE id_spt        = '$_POST[id]'");
 header('location:../../media.php?module='.$module);
}

?>