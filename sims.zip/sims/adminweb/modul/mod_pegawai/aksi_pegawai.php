<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";
include "../../../config/fungsi_seo.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus Pegawai
if ($module=='pegawai' AND $act=='hapus'){
  $query = "SELECT * FROM pegawai WHERE id_pegawai = '$_GET[id]'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFilex = $data['foto'];
  
  mysqli_query($connect,"DELETE FROM pegawai WHERE id_pegawai='$_GET[id]'");
  unlink("../../foto/".$namaFilex);
  unlink("../../foto/small_".$namaFilex);
  header('location:../../media.php?module='.$module);
}

// Input Data Pegawai
elseif ($module=='pegawai' AND $act=='input'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 
if (!empty($lokasi_file)){
	UploadFoto($nama_file_unik);
    mysqli_query($connect,"INSERT INTO pegawai (nama,
                                    nip,
                                    pangkat,
                                    golongan,
                                    jabatan,
									hp,
									email,
									alamat,
									foto) 
                            VALUES('$_POST[nama]',
                                   '$_POST[nip]',
                                   '$_POST[pangkat]',
                                   '$_POST[golongan]',
								   '$_POST[jabatan]',
								   '$_POST[hp]',
								   '$_POST[email]',
								   '$_POST[alamat]',
								   '$nama_file_unik')"); }
else {
    mysqli_query($connect,"INSERT INTO pegawai (nama,
                                    nip,
                                    pangkat,
                                    golongan,
                                    jabatan,
									hp,
									email,
									alamat) 
                            VALUES('$_POST[nama]',
                                   '$_POST[nip]',
                                   '$_POST[pangkat]',
                                   '$_POST[golongan]',
								   '$_POST[jabatan]',
								   '$_POST[hp]',
								   '$_POST[email]',
								   '$_POST[alamat]')"); }
  header('location:../../media.php?module='.$module);
}

// Update Pegawai
elseif ($module=='pegawai' AND $act=='update'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  $query = "SELECT * FROM pegawai WHERE id_pegawai = '$_POST[id]'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFilex = $data['foto'];

  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
    mysqli_query($connect,"UPDATE pegawai SET nama = '$_POST[nama]',
                                   nip  	   = '$_POST[nip]',
                                   pangkat 	   = '$_POST[pangkat]',
                                   golongan     = '$_POST[golongan]',
								   jabatan     = '$_POST[jabatan]',
								   hp     = '$_POST[hp]',
								   email     = '$_POST[email]',
								   alamat     = '$_POST[alamat]'
                             WHERE id_pegawai = '$_POST[id]'"); }
  else {
    UploadFoto($nama_file_unik);
	mysqli_query($connect,"UPDATE pegawai SET nama = '$_POST[nama]',
                                   nip  	   = '$_POST[nip]',
                                   pangkat 	   = '$_POST[pangkat]',
                                   golongan    = '$_POST[golongan]',
								   jabatan     = '$_POST[jabatan]',
								   hp     	   = '$_POST[hp]',
								   email       = '$_POST[email]',
								   alamat      = '$_POST[alamat]',
								   foto        =  '$nama_file_unik' 
                             WHERE id_pegawai = '$_POST[id]'"); 
  unlink("../../foto/".$namaFilex);
  unlink("../../foto/small_".$namaFilex);   }
  header('location:../../media.php?module='.$module);
}
?>
