<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_pegawai/aksi_pegawai.php";
switch($_GET['act']){
  // Tampil Data Pegawai
  default:
    echo "<h2>Data Pegawai</h2>
		  <input type=button class='tombol' value='Tambahkan Data Pegawai' 
		  onclick=\"window.location.href='?module=pegawai&act=tambahpegawai';\">
          <table>
          <tr><th>No</th><th>Nama</th><th>NIP</th><th>Pangkat/ Golongan</th><th>Jabatan</th><th>Aksi</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai DESC LIMIT $posisi,$batas");
  
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
	
      echo "<tr><td>$no</td>
                <td>$r[nama]</td>
                <td>$r[nip]</td>
                <td>$r[pangkat] / $r[golongan]</td>
				<td>$r[jabatan]</td>";
		        echo"<td><a href=?module=pegawai&act=editpegawai&id=$r[id_pegawai]><b>Edit</b></a> | 
		                <a href=$aksi?module=pegawai&act=hapus&id=$r[id_pegawai]><b>Hapus</a></b></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM pegawai"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
 
    break;
    
  case "tambahpegawai":
    echo "<h2>Tambah Data Pegawai</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=pegawai&act=input>
          <table>
          <tr><td width=90>Nama</td>	<td> : </td><td><input type=text name='nama' size=50></td></tr>
		  <tr><td width=90>NIP</td>		<td> : </td><td><input type=text name='nip' size=50></td></tr>
		  <tr><td width=90>Pangkat</td>	<td> : </td><td><input type=text name='pangkat' size=50></td></tr>
		  <tr><td width=90>Golongan</td><td> : </td><td><input type=text name='golongan' size=50></td></tr>
		  <tr><td width=90>Jabatan</td>	<td> : </td><td><input type=text name='jabatan' size=50></td></tr>
		  <tr><td>No Telepon</td>     	<td> : </td><td><input type=text name='hp' size=50></td></tr>
		  <tr><td>Email</td>     		<td> : </td><td><input type=text name='email' size=50></td></tr>
		  <tr><td>Alamat</td>     		<td> : </td><td><textarea name='alamat' style='width: 600px; height: 50px;'></textarea></td></tr>
		  <tr><td>File</td>      		<td> : </td><td><input type=file name='fupload' size=40> 
          <tr><td colspan=3><input type=submit class='tombol' value=Simpan>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
	
  case "editpegawai":
    $edit = mysqli_query($connect,"SELECT * FROM pegawai WHERE id_pegawai='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Data Pegawai</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=pegawai&act=update>
          <input type=hidden name='id' value='$r[id_pegawai]'>
          <table>
          <tr><td width=90>Nama</td>	<td> : </td><td><input type=text name='nama' size=50 value='$r[nama]'></td></tr>
		  <tr><td width=90>NIP</td>		<td> : </td><td><input type=text name='nip' size=50 value='$r[nip]'></td></tr>
		  <tr><td width=90>Pangkat</td>	<td> : </td><td><input type=text name='pangkat' size=50 value='$r[pangkat]'></td></tr>
		  <tr><td width=90>Golongan</td><td> : </td><td><input type=text name='golongan' size=50 value='$r[golongan]'></td></tr>
		  <tr><td width=90>Jabatan</td>	<td> : </td><td><input type=text name='jabatan' size=50 value='$r[jabatan]'></td></tr>
		  <tr><td>No Telepon</td>     	<td> : </td><td><input type=text name='hp' size=40 value='$r[hp]'></td></tr>
		  <tr><td>Email</td>     		<td> : </td><td><input type=text name='email' size=40 value='$r[email]'></td></tr>
		  <tr><td>Alamat</td>     		<td> : </td><td><input type=text name='alamat' size=100 value='$r[alamat]'></td></tr>
		  <tr><td>File</td>      		<td> : </td><td><input type=file name='fupload' size=40> 
          <tr><td colspan=3><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
}
}
?>
