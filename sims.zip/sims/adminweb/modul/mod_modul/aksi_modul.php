<?php
session_start();
include "../../../config/koneksi.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus modul
if ($module=='modul' AND $act=='hapus'){
  mysqli_query($connect,"DELETE FROM modul WHERE id_modul='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input modul
elseif ($module=='modul' AND $act=='input'){
  // Input data modul
  mysqli_query($connect,"INSERT INTO modul(nama_modul,
                                 link) 
	                       VALUES('$_POST[nama_modul]',
                                '$_POST[link]')");
  header('location:../../media.php?module='.$module);
}

// Update modul
elseif ($module=='modul' AND $act=='update'){
  mysqli_query($connect,"UPDATE modul SET nama_modul = '$_POST[nama_modul]',
                                link       = '$_POST[link]'  
                          WHERE id_modul   = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
}
?>
