<?php
$aksi="modul/mod_modul/aksi_modul.php";
switch($_GET['act']){
  // Tampil Modul
  default:
    echo "<h2>Manajemen Modul</h2>
          <input type=button class='tombol' value='Tambah Modul' onclick=\"window.location.href='?module=modul&act=tambahmodul';\">
          <table>
          <tr><th>No</th><th>Nama Modul</th><th>Link</th><th>Aksi</th></tr>";
    $tampil=mysqli_query($connect,"SELECT * FROM modul ORDER BY id_modul");
	$i=1;
    while ($r=mysqli_fetch_array($tampil)){
      echo "<tr><td>$i</td>
            <td>$r[nama_modul]</td>
            <td><a href=$r[link]>$r[link]</a></td>
            <td><a href=?module=modul&act=editmodul&id=$r[id_modul]><b>Edit</b></a> | 
	              <a href=$aksi?module=modul&act=hapus&id=$r[id_modul]><b>Hapus</b></a>
            </td></tr>";
			$i++;
    }
    echo "</table>";
    break;

  case "tambahmodul":
    echo "<h2>Tambah Modul</h2>
          <form method=POST action='$aksi?module=modul&act=input'>
          <table>
          <tr><td>Nama Modul</td> <td> : <input type=text name='nama_modul'></td></tr>
          <tr><td>Link</td>       <td> : <input type=text name='link' size=30></td></tr>
          <tr><td colspan=2><input type=submit class='tombol' value=Simpan>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;
 
  case "editmodul":
    $edit = mysqli_query($connect,"SELECT * FROM modul WHERE id_modul='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Modul</h2>
          <form method=POST action=$aksi?module=modul&act=update>
          <input type=hidden name=id value='$r[id_modul]'>
          <table>
          <tr><td>Nama Modul</td>     <td> : <input type=text name='nama_modul' value='$r[nama_modul]'></td></tr>
          <tr><td>Link</td>     <td> : <input type=text name='link' size=30 value='$r[link]'></td></tr>
          <tr><td colspan=2><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
    break;  
}
?>
