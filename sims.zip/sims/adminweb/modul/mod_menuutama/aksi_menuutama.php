<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/fungsi_seo.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Input menu utama
if ($module=='menuutama' AND $act=='input'){
  mysqli_query($connect,"INSERT INTO mainmenu(nama_menu,link) VALUES('$_POST[nama_menu]','$_POST[link]')");
  header('location:../../media.php?module='.$module);
}

// Update menu utama
elseif ($module=='menuutama' AND $act=='update'){
  mysqli_query($connect,"UPDATE mainmenu SET nama_menu='$_POST[nama_menu]', link='$_POST[link]', aktif='$_POST[aktif]' 
               WHERE id_main = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
}

?>
