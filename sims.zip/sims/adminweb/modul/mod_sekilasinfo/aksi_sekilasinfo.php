<?php
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus sekilas info
if ($module=='sekilasinfo' AND $act=='hapus'){
  $data=mysqli_fetch_array(mysqli_query($connect,"DELETE FROM sekilasinfo WHERE id_sekilas='$_GET[id]'"));  
  header('location:../../media.php?module='.$module);
}

// Input sekilas info
elseif ($module=='sekilasinfo' AND $act=='input'){
  // Apabila ada gambar yang diupload
    mysqli_query($connect,"INSERT INTO sekilasinfo(info,
                                    tgl_posting) 
                            VALUES('$_POST[info]',
                                   '$tgl_sekarang')");
  header('location:../../media.php?module='.$module);
}

// Update sekilas info
elseif ($module=='sekilasinfo' AND $act=='update'){
    mysqli_query($connect,"UPDATE sekilasinfo SET info = '$_POST[info]'
                             WHERE id_sekilas = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
  }
?>
