<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_masuk/aksi_masuk.php";
$disp="modul/mod_disposisi/disposisi.php";
switch($_GET['act']){
  // Tampil Surat Masuk
  default:
    echo "<h2>Surat Masuk</h2>
          <input type=button class='tombol' value='Tambahkan Surat Masuk' onclick=\"window.location.href='?module=masuk&act=tambahsurat';\">
          <table>
          <tr><th>No</th><th>Tanggal Register</th><th>Nomor Surat</th><th>Asal Surat</th><th>Tanggal Surat</th><th>Perihal</th><th>File</th>
		  <th>Aksi</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($connect,"SELECT * FROM surat_masuk ORDER BY id_surat DESC LIMIT $posisi,$batas");
      
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
      $reg=tgl_indo($r['tgl_register']);
	  $tgl=tgl_indo($r['tgl_masuk']);
	  
      echo "<tr><td>$no</td>
	  			<td>$reg</td>
                <td>$r[nomor_surat]</td>
                <td>$r[asal_surat]</td>
				<td>$tgl</td><td>";
		$kalimat=strtok(nl2br($r['deskripsi'])," ");
				for ($s=1;$s<=10;$s++){
      echo ($kalimat);
      echo (" "); // Spasi antar kalimat
      $kalimat=strtok(" "); // Potong per kalimat
      } 				
				echo"....</td><td><a href='$aksi?module=download&id=".$r['id_surat']."'>Download</a></td>
                <td><a href=?module=masuk&act=editmasuk&id=$r[id_surat]><b>Edit</b></a> | 
				<a href=$aksi?module=masuk&act=hapus&id=$r[id_surat]><b>Hapus</a></b> | 
				<a href=?module=disposisi&id=$r[id_surat]><b>Disp</b></a> | 
				<a href=?module=spt&id=$r[id_surat]><b>SPT</b></a> </td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM surat_masuk"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
 
    break;
  
  case "tambahsurat":
    echo "<h2>Tambah Surat Masuk</h2>
          <form method=POST action='$aksi?module=masuk&act=input' enctype='multipart/form-data'>
		  <input type=hidden name=oleh value=$_SESSION[nama]>
          <table>
		  <tr><td>Tanggal Register</td>  	<td> : </td><td><input type=text id=tgl_mulai name='tgl_register' size=10></td></tr>
          <tr><td>Indeks</td>  				<td> : </td><td>
          <select name='indeks'>
            <option value=0 selected>- Pilih Indeks -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM kategori ORDER BY nama_kategori");
            while($r=mysqli_fetch_array($tampil)){
              echo "<option value=$r[indeks]>$r[nama_kategori]</option>";
            }
    echo "</select>&nbsp;&nbsp;No. Reg &nbsp;&nbsp;<input type=text name='no_reg' size=15></td></tr>
		  <tr><td width=70>Nomor Surat</td>     <td> : </td><td><input type=text name='nomor_surat' size=60></td></tr>
          <tr><td>Asal Surat</td>    		 	<td> : </td><td><input type=text name='asal_surat' size=15></td></tr>
          <tr><td>Tanggal Surat</td>     		<td> : </td><td><input type=text id=datepicker name='tgl_masuk' size=15></td></tr>
          <tr><td>Perihal</td>  				<td> : </td><td><textarea name='deskripsi' style='width: 600px; height: 50px;'></textarea></td></tr>
		  <tr><td>Keterangan</td>    		 	<td> : </td><td><input type=text name='keterangan' size=60></td></tr>
          <tr><td>File</td>      				<td> : </td><td><input type=file name='fupload' size=40> 
          <tr><td colspan=3><input type=submit class='tombol' value=Simpan>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;
    
  case "editmasuk":
    $edit = mysqli_query($connect,"SELECT * FROM surat_masuk WHERE id_surat='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Surat Masuk</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=masuk&act=update>
          <input type=hidden name=id value=$r[id_surat]>
		  <input type=hidden name=edit value=$_SESSION[nama]>
          <table>
		  <tr><td width=70>Tanggal Register</td><td> : </td><td>
		  <input type=text id=tgl_mulai name='tgl_register' size=10 value='$r[tgl_register]'></td></tr>
          <tr><td>Indeks</td>  <td> : </td><td><select name='indeks'>";
          $tampil=mysqli_query($connect,"SELECT * FROM kategori ORDER BY nama_kategori");
          if ($r['indeks']==0){
            echo "<option value=0 selected>- Pilih Indeks -</option>";
          }   
          while($w=mysqli_fetch_array($tampil)){
            if ($r['indeks']==$w['indeks']){
              echo "<option value=$w[indeks] selected>$w[nama_kategori]</option>";
            }
            else{
              echo "<option value=$w[indeks]>$w[nama_kategori]</option>";
            }
          }
    echo "</select>&nbsp;&nbsp;No. Reg &nbsp;&nbsp;<input type=text name='no_reg' value='$r[register]' size=15></td></tr>
          <tr><td width=70>Nomor Surat</td><td> : </td><td><input type=text name='nomor_surat' size=60 value='$r[nomor_surat]'></td></tr>
		  <tr><td>Asal Surat</td>     <td> : </td><td><input type=text name='asal_surat' value='$r[asal_surat]' size=60></td></tr>
          <tr><td>Tanggal Surat</td>  <td> : </td><td><input type=text id=datepicker name='tgl_masuk' value='$r[tgl_masuk]' size=10></td></tr>
		  <tr><td>Perihal</td>        <td> : </td><td><textarea name='deskripsi' style='width: 600px; height: 50px;'>$r[deskripsi]</textarea></td></tr>
		  <tr><td>Keterangan</td>     <td> : </td><td><input type=text name='keterangan' value='$r[keterangan]' size=60></td></tr>
          <tr><td>Ganti File</td>    <td> : </td><td><input type=file name='fupload' size=30> *)</td></tr>
          <tr><td colspan=3>*) Apabila file tidak diubah, dikosongkan saja.</td></tr>
          <tr><td colspan=3><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
}
}
?>
