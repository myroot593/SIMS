<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus Surat
if ($module=='masuk' AND $act=='hapus'){
  $id = $_GET['id'];
  $query = "SELECT * FROM surat_masuk WHERE id_surat = '$id'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFile = $data['file']; 
  mysqli_query($connect,"DELETE FROM surat_masuk WHERE id_surat='$_GET[id]'");
  unlink("../../upload/surat_masuk/".$namaFile);
  header('location:../../media.php?module='.$module);
}

// Input Surat Masuk
elseif ($module=='masuk' AND $act=='input'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  // Apabila ada file yang diupload
  if (!empty($lokasi_file)){
    UploadFile($nama_file_unik);
    mysqli_query($connect,"INSERT INTO surat_masuk(indeks,
									register,
									tgl_register,
                                    nomor_surat,
                                    asal_surat,
                                    tgl_masuk,
                                    deskripsi,
									keterangan,
									oleh,
									file) 
                            VALUES('$_POST[indeks]',
							       '$_POST[no_reg]',
								   '$_POST[tgl_register]',
                                   '$_POST[nomor_surat]',
                                   '$_POST[asal_surat]',
                                   '$_POST[tgl_masuk]',
								   '$_POST[deskripsi]',
								   '$_POST[keterangan]',
								   '$_POST[oleh]',
                                   '$nama_file_unik')");
  }
  else{
    mysqli_query($connect,"INSERT INTO surat_masuk (indeks,
									register,
									tgl_register,
                                    nomor_surat,
                                    asal_surat,
                                    tgl_masuk,
                                    deskripsi,
									keterangan,
									oleh)
                            VALUES('$_POST[indeks]',
							       '$_POST[no_reg]',
								   '$_POST[tgl_register]',
                                   '$_POST[nomor_surat]',
                                   '$_POST[asal_surat]',
                                   '$_POST[tgl_masuk]',
								   '$_POST[deskripsi]',
								   '$_POST[keterangan]',
								   '$_POST[oleh]')");
  }
  header('location:../../media.php?module='.$module);
}

// Update Surat Masuk
elseif ($module=='masuk' AND $act=='update'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  $query = "SELECT * FROM surat_masuk WHERE id_surat = '$_POST[id]'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFilex = $data['file'];
  
  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
    mysqli_query($connect,"UPDATE surat_masuk SET nomor_surat = '$_POST[nomor_surat]',
								   tgl_register     = '$_POST[tgl_register]',
                                   indeks			= '$_POST[indeks]',
								   register         =  '$_POST[no_reg]',
                                   asal_surat  = '$_POST[asal_surat]',
								   tgl_masuk   = '$_POST[tgl_masuk]',
                                   deskripsi   = '$_POST[deskripsi]',
								   keterangan   = '$_POST[keterangan]',
								   diedit		= '$_POST[edit]'
                             WHERE id_surat   = '$_POST[id]'");
  }
  else{
    UploadFile($nama_file_unik);
    mysqli_query($connect,"UPDATE surat_masuk SET nomor_surat = '$_POST[nomor_surat]',
								   tgl_register = '$_POST[tgl_register]',
                                   indeks			= '$_POST[indeks]',
								   register         =  '$_POST[no_reg]',
                                   asal_surat  = '$_POST[asal_surat]',
								   tgl_masuk   = '$_POST[tgl_masuk]',
                                   deskripsi   = '$_POST[deskripsi]',
								   keterangan   = '$_POST[keterangan]',
								   diedit		= '$_POST[edit]',
                                   file      = '$nama_file_unik'   
                             WHERE id_surat   = '$_POST[id]'");
 
  unlink("../../upload/surat_masuk/".$namaFilex);
  }
  header('location:../../media.php?module='.$module);
}

// Download Surat
elseif ($module=='download'){
$id = $_GET['id'];
$query = "SELECT * FROM surat_masuk WHERE id_surat = '$id'";
$hasil = mysqli_query($connect,$query);
$data = mysqli_fetch_array($hasil);

header("Content-Disposition: attachment; filename=".$data['file']);
header("Content-length: ".$data['size']);
header("Content-type: ".$data['type']);
$fp = fopen("../../upload/surat_masuk/".$data['file'], 'r');
$content = fread($fp, filesize('../../upload/surat_masuk/'.$data['file']));
fclose($fp);
echo $content;
exit; 
}

?>
