<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus Disposisi
if ($module=='disposisi' AND $act=='hapusdisposisi'){
  $id=$_GET['srt'];
  mysqli_query($connect,"DELETE FROM disposisi WHERE id='$_GET[id]'");
  header('location:../../media.php?module='.$module.'&id='.$id);
}

// Input Disposisi Surat
elseif ($module=='disposisi' AND $act=='inputdisposisi'){
 $id=$_POST['id'];
    mysqli_query($connect,"INSERT INTO disposisi (id_surat,
                                    kepada,
                                    isi,
                                    sifat,
                                    batas,
									catatan) 
                            VALUES('$_POST[id]',
                                   '$_POST[kepada]',
                                   '$_POST[isi]',
                                   '$_POST[sifat]',
								   '$_POST[batas]',
								   '$_POST[catatan]')");
  header('location:../../media.php?module='.$module.'&id='.$id);
}

elseif ($module=='disposisi' AND $act=='update'){
 $srt=$_POST['srt'];
 mysqli_query($connect,"UPDATE disposisi SET kepada 	   = '$_POST[kepada]',
                                   isi		   = '$_POST[isi]',
                                   sifat       = '$_POST[sifat]',
								   batas       = '$_POST[batas]',
                                   catatan     = '$_POST[catatan]'
                             WHERE id          = '$_POST[id]'");
 header('location:../../media.php?module='.$module.'&id='.$srt);
}

?>
