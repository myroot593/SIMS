<?php 
include "../../../config/koneksi.php";
include "../../../config/fungsi_indotgl.php";

    $id = $_GET['id'];
	$query = "SELECT disposisi.*,surat_masuk.* FROM disposisi,surat_masuk WHERE disposisi.id_surat = surat_masuk.id_surat AND disposisi.id = '$id'";
	$hasil = mysqli_query($connect,$query);
	$data = mysqli_fetch_array($hasil);
	$tgl_masuk=tgl_indo($data['tgl_masuk']);	
	$batas=tgl_indo($data['batas']);	
?>

<html>
<head>
<style type="text/css" media="print">
	table {border: solid 1px #000; border-collapse: collapse; width: 100%}
	tr { border: solid 1px #000}
	td { padding: 7px 5px}
	h3 { margin-bottom: -17px }
	h2 { margin-bottom: 0px }
</style>
<style type="text/css" media="screen">
	table {border: solid 1px #000; border-collapse: collapse; width: 60%}
	tr { border: solid 1px #000}
	td { padding: 7px 5px}
	h3 { margin-bottom: -17px }
	h2 { margin-bottom: 0px }
</style>
</head>

<body onLoad="window.print()">
<table>
	<tr><td colspan="3" align="center">
	<h2>Bappeda Kabupaten Pangandaran</h2>
	Alamat : Jalan Raya Bojong Salawe - Parigi
	</td>
	</tr>
	
	<tr><td colspan="3" align="center" style="padding: 15px 0"><b style="font-size: 21px;">KARTU DISPOSISI</b></td></tr>
	<tr><td width="25%"><b>Indeks</b></td><td width="35%">: <?php echo"$data[indeks]/$data[register]"; ?></td><td><b>Sifat : </b>
	<?php echo"$data[sifat]"; ?></td></tr>
	<tr><td width="25%"></td><td width="35%"></td><td><b>Tanggal Penyelesaian : </b><?php echo"$batas"; ?></td></tr>
	<tr><td width="25%"><b>Perihal</b></td><td colspan="2">: <?php echo"$data[deskripsi]"; ?></td></tr>
	<tr><td width="25%"><b>Tanggal Surat</b></td><td colspan="2">: <?php echo"$tgl_masuk"; ?></td></tr>
	<tr><td width="25%"><b>Nomor Surat</b></td><td colspan="2">: <?php echo"$data[nomor_surat]"; ?></td></tr>
	<tr><td><b>Asal Surat</b></td><td colspan="2">: <?php echo"$data[asal_surat]"; ?></td></tr>
	<tr><td><b>Lampiran</b></td><td colspan="2">: -</td></tr>
	<tr><td style="height: 100px" valign="top" colspan="2"><b>Instruksi/ Informasi : </b> <br><br>

	<ol>
	<?php 
	echo"$data[isi]";
	?>
	</ol>
	
	
	</td><td valign="top" width="50%" style="border-left: solid 1px">
	<b>Diteruskan kepada  : </b>
	<ol>
	<?php 
	echo"1. $data[kepada] <br>2. <br>3. <br>4. <br>5. ";
	?>
	</ol>
	</td></tr>
	<tr><td colspan="3" style="line-height: 30px" align="center"><b>P = Penting, B = Biasa, R = Rahasia</b></td>
	</tr>
</table>
</body>
</html>
