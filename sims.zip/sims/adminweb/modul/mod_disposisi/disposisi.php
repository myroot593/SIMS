<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_disposisi/aksi_disposisi.php";
$cetak="modul/mod_disposisi/cetak_disposisi.php";
switch($_GET['act']){
  // Tampil Disposisi Surat
  default:
    $id = $_GET['id'];
	$query = "SELECT * FROM surat_masuk WHERE id_surat = '$id'";
	$hasil = mysqli_query($connect,$query);
	$data = mysqli_fetch_array($hasil);
        echo "<h2>Disposisi Surat</h2>
          <input type=button class='tombol' value='Tambahkan Disposisi Surat' 
		  onclick=\"window.location.href='?module=disposisi&act=tambahdisposisi&id=$id';\">
          <h3>Perihal Surat : $data[deskripsi]</h3>
		  <table>
          <tr><th>No</th><th>Ditujukan kepada</th><th>Isi</th><th>Sifat</th><th>Aksi</th>
		  </tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($connect,"SELECT * FROM disposisi WHERE id_surat='$id' ORDER BY id DESC LIMIT $posisi,$batas");
  
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
      echo "<tr><td>$no</td>
                <td>$r[kepada]</td>
                <td>$r[isi]</td>
				<td>$r[sifat]</td>
                <td><a href=?module=disposisi&act=editdisposisi&id=$r[id]><b>Edit</b></a> | 
				<a href=$aksi?module=disposisi&act=hapusdisposisi&id=$r[id]&srt=$id><b>Hapus</b></a> | 
				<a href=$cetak?id=$r[id] target='_blank'><b>Cetak</b></a></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM disposisi"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
     break;

 case "tambahdisposisi":
	$id = $_GET['id'];
	$query = "SELECT * FROM surat_masuk WHERE id_surat = '$id'";
	$hasil = mysqli_query($connect,$query);
	$data = mysqli_fetch_array($hasil);
    echo "<h2>Tambah Disposisi Surat</h2>
          <form method=POST action='$aksi?module=disposisi&act=inputdisposisi' enctype='multipart/form-data'>
		  <input type=hidden name=id value=$_GET[id]>
		  <h3>Perihal Surat : $data[deskripsi]</h3>
          <table>
          <tr><td width=70>Ditujukan Kepada</td><td> : <input type=text name='kepada' size=60></td></tr>
          <tr><td>Isi</td>  					<td> <textarea name='isi' style='width: 600px; height: 50px;'></textarea></td></tr>
		  <tr><td>Sifat</td>    		 		<td> : <select name='sifat'  style='width: 103px' required>
		  <option value=''> - Sifat - </option>";
				$l_sifat	= array('Biasa','Rahasia','Penting');
				
				for ($i = 0; $i < sizeof($l_sifat); $i++) {
					if ($l_sifat[$i] == $sifat) {
						echo "<option selected value='".$l_sifat[$i]."'>".$l_sifat[$i]."</option>";
					} else {
						echo "<option value='".$l_sifat[$i]."'>".$l_sifat[$i]."</option>";
					}				
				}			
			echo"</select></td></tr>
		  <tr><td>Batas Waktu</td>    		    <td> : <input type=text id=datepicker name='batas' size=10></td></tr>
		  <tr><td>Catatan</td>  				<td> <textarea name='catatan' style='width: 600px; height: 50px;'></textarea></td></tr>
          <tr><td colspan=2><input type=submit class='tombol' value=Simpan>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;

  case "editdisposisi":
    $edit = mysqli_query($connect,"SELECT * FROM surat_masuk,disposisi WHERE surat_masuk.id_surat=disposisi.id_surat AND disposisi.id='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Disposisi Surat</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=disposisi&act=update>
          <input type=hidden name=id value=$r[id]>
		  <input type=hidden name=srt value=$r[id_surat]>
          <table>
          <tr><td width=70>Ditujukan Kepada</td><td> : <input type=text name='kepada' size=60 value='$r[kepada]'></td></tr>
          <tr><td>Isi</td>     		  <td> <textarea name='isi' style='width: 600px; height: 50px;'>$r[isi]</textarea></td></tr>
		  <tr><td>Sifat</td>    		 		<td> : <select name='sifat'  style='width: 103px' required>
		  <option value=''> - Sifat - </option>";
				$l_sifat	= array('Biasa','Rahasia','Penting');
				
				for ($i = 0; $i < sizeof($l_sifat); $i++) {
					if ($l_sifat[$i] == $sifat) {
						echo "<option selected value='".$l_sifat[$i]."'>".$l_sifat[$i]."</option>";
					} else {
						echo "<option value='".$l_sifat[$i]."'>".$l_sifat[$i]."</option>";
					}				
				}			
		  echo"</select></td></tr>
          <tr><td>Batas</td>  		  <td> : <input type=text id=datepicker name='batas' value='$r[batas]' size=10></td></tr>
		  <tr><td>Catatan</td>        <td> <textarea name='catatan' style='width: 600px; height: 50px;'>$r[catatan]</textarea></td></tr>
          <tr><td colspan=2><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
	
}
}
?>
