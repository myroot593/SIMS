<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus Surat
if ($module=='keluar' AND $act=='hapus'){
  $id = $_GET['id'];
  $query = "SELECT * FROM surat_keluar WHERE id_surat = '$id'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFile = $data['file']; 
  mysqli_query($connect,"DELETE FROM surat_keluar WHERE id_surat='$_GET[id]'");
  unlink("../../upload/surat_keluar/".$namaFile);
  header('location:../../media.php?module='.$module);
}

// Input Surat Keluar
elseif ($module=='keluar' AND $act=='input'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  // Apabila ada file yang diupload
  if (!empty($lokasi_file)){
    UploadFile2($nama_file_unik);
    mysqli_query($connect,"INSERT INTO surat_keluar(indeks,
									register,
									tgl_register,
                                    tujuan,
                                    tgl_keluar,
                                    deskripsi,
									keterangan,
									oleh,
									file) 
                            VALUES('$_POST[indeks]',
							       '$_POST[no_reg]',
								   '$_POST[tgl_reg]',
                                   '$_POST[tujuan]',
                                   '$_POST[tgl_keluar]',
								   '$_POST[deskripsi]',
								   '$_POST[keterangan]',
								   '$_POST[oleh]',
                                   '$nama_file_unik')");
  }
  else{
    mysqli_query($connect,"INSERT INTO surat_keluar (indeks,
									register,
                                    tgl_register,
                                    tujuan,
                                    tgl_keluar,
                                    deskripsi,
									keterangan,
									oleh)	
                            VALUES('$_POST[indeks]',
							       '$_POST[no_reg]',
                                   '$_POST[tgl_reg]',
                                   '$_POST[tujuan]',
                                   '$_POST[tgl_keluar]',
								   '$_POST[deskripsi]',
								   '$_POST[keterangan]',
								   '$_POST[oleh]')");
  }
  header('location:../../media.php?module='.$module);
}

// Update Surat Keluar
elseif ($module=='keluar' AND $act=='update'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  $query = "SELECT * FROM surat_keluar WHERE id_surat = '$_POST[id]'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFilex = $data['file'];
  
  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
    mysqli_query($connect,"UPDATE surat_keluar SET tgl_register = '$_POST[tgl_reg]',
                                   indeks			= '$_POST[indeks]',
								   register         =  '$_POST[no_reg]',
                                   tujuan      = '$_POST[tujuan]',
								   tgl_keluar   = '$_POST[tgl_keluar]',
                                   deskripsi   = '$_POST[deskripsi]',
								   keterangan   = '$_POST[keterangan]',
								   diedit		= '$_POST[edit]'
                             WHERE id_surat   = '$_POST[id]'");
  }
  else{
    UploadFile2($nama_file_unik);
    mysqli_query($connect,"UPDATE surat_keluar SET tgl_register = '$_POST[tgl_reg]',
                                   indeks			= '$_POST[indeks]',
								   register         =  '$_POST[no_reg]',
                                   tujuan      = '$_POST[tujuan]',
								   tgl_keluar   = '$_POST[tgl_keluar]',
                                   deskripsi   = '$_POST[deskripsi]',
								   keterangan   = '$_POST[keterangan]',
								   diedit		= '$_POST[edit]',
                                   file      = '$nama_file_unik'   
                             WHERE id_surat   = '$_POST[id]'");
 
  unlink("../../upload/surat_keluar/".$namaFilex);
  }
  header('location:../../media.php?module='.$module);
}

// Download Surat
elseif ($module=='download'){
$id = $_GET['id'];
$query = "SELECT * FROM surat_keluar WHERE id_surat = '$id'";
$hasil = mysqli_query($connect,$query);
$data = mysqli_fetch_array($hasil);

header("Content-Disposition: attachment; filename=".$data['file']);
header("Content-length: ".$data['size']);
header("Content-type: ".$data['type']);
$fp = fopen("../../upload/surat_keluar/".$data['file'], 'r');
$content = fread($fp, filesize('../../upload/surat_keluar/'.$data['file']));
fclose($fp);
echo $content;
exit; 
}

?>
