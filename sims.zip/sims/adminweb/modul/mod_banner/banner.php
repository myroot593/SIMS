<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_banner/aksi_banner.php";
switch($_GET['act']){
  // Tampil banner
  default:
    echo "<h2>Banner</h2>
		  <input type=button class='tombol' value='Tambahkan Gambar Banner' 
		  onclick=\"window.location.href='?module=banner&act=tambahbanner';\">
          <table>
          <tr><th>No</th><th>Nama File</th><th>Keterangan</th><th>Aksi</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($connect,"SELECT * FROM banner ORDER BY id_banner DESC LIMIT $posisi,$batas");
  
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
	$tgl=tgl_indo($r['tanggal']);
      echo "<tr><td>$no</td>
                <td>$r[nama]</td>
                <td>$r[keterangan]</td>";
		        echo"<td><a href=?module=banner&act=editbanner&id=$r[id_banner]><b>Edit</b></a> | 
		                <a href=$aksi?module=banner&act=hapus&id=$r[id_banner]><b>Hapus</a></b></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM banner"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
 
    break;
    
  case "tambahbanner":
    echo "<h2>Tambah Gambar Banner</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=banner&act=input>
		  <input type=hidden name='nama' value='$_SESSION[nama]'>
          <table>
		  <tr><td>File</td>      		<td> : </td><td><input type=file name='fupload' size=40></td></tr> 
		  <tr><td>Keterangan</td>     	<td> : </td><td><textarea name='keterangan' style='width: 600px; height: 350px;'></textarea></td></tr>
		  <tr><td colspan=3><input type=submit class='tombol' value=Simpan>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
	
  case "editbanner":
    $edit = mysqli_query($connect,"SELECT * FROM banner WHERE id_banner='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Gambar Banner</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=banner&act=update>
          <input type=hidden name='id' value='$r[id_banner]'>
          <table>
		  <tr><td>File</td>      		<td> : </td><td><input type=file name='fupload' size=40> 
		  <tr><td>Keterangan</td>     			<td> : </td><td><textarea name='keterangan' style='width: 600px; height: 350px;'>$r[keterangan]</textarea></td></tr>
		  <tr><td colspan=3><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
}
}
?>
