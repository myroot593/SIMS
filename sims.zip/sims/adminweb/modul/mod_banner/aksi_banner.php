<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";
include "../../../config/fungsi_seo.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus Banner
if ($module=='banner' AND $act=='hapus'){
  $query = "SELECT * FROM banner WHERE id_banner = '$_GET[id]'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFilex = $data['nama'];
  mysqli_query($connect,"DELETE FROM banner WHERE id_banner='$_GET[id]'");
  unlink("../../../banner/".$namaFilex);
  header('location:../../media.php?module='.$module);
}

// Input Data Banner
elseif ($module=='banner' AND $act=='input'){
if (!empty($lokasi_file)){
	UploadBerita($nama_file_unik);
    mysqli_query($connect,"INSERT INTO banner (nama,
                                    keterangan) 
                            VALUES('$_POST[judul]',
                                   '$_POST[keterangan]')"); }
else {
    mysqli_query($connect,"INSERT INTO banner (keterangan) 
                            VALUES('$_POST[keterangan]')"); }
  header('location:../../media.php?module='.$module);
}

// Update Pegawai
elseif ($module=='banner' AND $act=='update'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  $query = "SELECT * FROM berita WHERE id_berita = '$_POST[id]'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFilex = $data['gambar'];

  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
    mysqli_query($connect,"UPDATE berita SET judul 	   = '$_POST[judul]',
                                   isi_berita  = '$_POST[isi]'
                             WHERE id_berita = '$_POST[id]'"); }
  else {
    UploadBerita($nama_file_unik);
	mysqli_query($connect,"UPDATE berita SET judul 	   = '$_POST[judul]',
                                   isi_berita  = '$_POST[isi]',
								   gambar      =  '$nama_file_unik' 
                             WHERE id_berita = '$_POST[id]'"); 
  unlink("../../foto_berita/".$namaFilex);
  unlink("../../foto_berita/small_".$namaFilex);   }
  header('location:../../media.php?module='.$module);
}
?>
