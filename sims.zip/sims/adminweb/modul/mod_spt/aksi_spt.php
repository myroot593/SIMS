<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus SPT
if ($module=='spt' AND $act=='hapusspt'){
//  mysql_query("DELETE FROM spt WHERE id_spt='$_GET[id]'");
  
    $qu = "SELECT * FROM spt_pegawai WHERE nomor_spt = '$_GET[id]'";
	$hsl = mysqli_query($connect,$qu);
	$dt = mysqli_fetch_array($hsl);
    
	//$query = "SELECT * FROM spt,spt_pegawai WHERE spt.nomor_spt=spt_pegawai.nomor_spt AND spt_pegawai.nomor_spt = '$dt[nomor_spt]'";
	//$hasil = mysql_query($query);
	//$data = mysql_fetch_array($hasil);
	$num = mysqli_num_rows($hsl);
	$s=$dt['nomor_spt'];
	
	if($num ==1) { mysqli_query($connect,"DELETE FROM spt WHERE nomor_spt='$s'");
	mysqli_query($connect,"DELETE FROM spt_pegawai WHERE id_sptpeg='$_GET[no]'"); }
	else {  	mysqli_query($connect,"DELETE FROM spt_pegawai WHERE id_sptpeg='$_GET[no]'");  }
$id=$_GET['srt'];
  header('location:../../media.php?module='.$module.'&id='.$id);
}

// Input SPT
elseif ($module=='spt' AND $act=='inputspt'){
    mysqli_query($connect,"INSERT INTO spt 	(nomor_spt,
									id_surat,
                                    tgl_spt,
                                    dasar,
                                    uraian,
                                    tgl_mulai,
									tgl_selesai,
									waktu,
									tempat) 
                            VALUES('$_POST[nomor]',
								   '$_POST[id]',
                                   '$_POST[tgl_spt]',
                                   '$_POST[dasar]',
                                   '$_POST[uraian]',
								   '$_POST[tgl_mulai]',
								   '$_POST[tgl_selesai]',
								   '$_POST[waktu]',
								   '$_POST[tempat]')");
for($i=0; $i<=6; $i++){
$pengikut = $_POST['pengikut'][$i];
if($pengikut<>0) {
	mysqli_query($connect,"INSERT INTO spt_pegawai (nomor_spt,
                                    id_pegawai,
									id_surat) 
                            VALUES('$_POST[nomor]',
                                   '$pengikut',
								   '$_POST[id]')");	}		}				   
$id=$_POST['id'];
  header('location:../../media.php?module='.$module.'&id='.$id);
}

elseif ($module=='spt' AND $act=='update'){
$id=$_POST['srt'];
 mysqli_query($connect,"UPDATE spt SET nomor_spt 	   		 = '$_POST[nomor]',
                                   tgl_spt		 = '$_POST[tgl_spt]',
                                   dasar         = '$_POST[dasar]',
								   uraian        = '$_POST[uraian]',
                                   tgl_mulai     = '$_POST[tgl_mulai]',
								   tgl_selesai   = '$_POST[tgl_selesai]',
								   waktu    	 = '$_POST[waktu]',
								   tempat     	 = '$_POST[tempat]'
								   WHERE id_spt  = '$_POST[id]'");
 mysqli_query($connect,"UPDATE spt_pegawai SET nomor_spt = '$_POST[nomor]' WHERE id_surat  = '$_POST[srt]'");	
 
if ($_POST['pengikut'][0]<>0) {
mysqli_query($connect,"DELETE FROM spt_pegawai WHERE id_surat='$_POST[srt]'"); 

for($i=0; $i<=6; $i++){
$pengikut = $_POST['pengikut'][$i];
if($pengikut<>0) {
//	mysql_query("DELETE FROM spt_pegawai WHERE id_surat='$_POST[srt]'");
	
	mysqli_query($connect,"INSERT INTO spt_pegawai (nomor_spt,
                                    id_pegawai,
									id_surat) 
                            VALUES('$_POST[nomor]',
                                   '$pengikut',
								   '$_POST[srt]')");	
  	}		}		}
								   
 header('location:../../media.php?module='.$module.'&id='.$id);
}

?>
