<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_spt/aksi_spt.php";
$cetak="modul/mod_spt/cetak_spt.php";

switch($_GET['act']){
  // Tampil Surat Perintah Tugas
  default:
    $id = $_GET['id'];
	$query = "SELECT * FROM surat_masuk WHERE id_surat = '$id'";
	$hasil = mysqli_query($connect,$query);
	$data = mysqli_fetch_array($hasil);
        echo "<h2>Surat Perintah Tugas</h2>
          <input type=button class='tombol' value='Tambahkan Surat Perintah Tugas' 
		  onclick=\"window.location.href='?module=spt&act=tambahspt&id=$id';\">
          <h3>Perihal Surat : $data[deskripsi]</h3>
		  <table>
          <tr><th>No</th><th>Nomor SPT</th><th>Penerima Tugas</th><th>Kegiatan</th><th>Tanggal Kegiatan</th><th>Tempat</th><th>Aksi</th>
		  </tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($connect,"SELECT * FROM spt,spt_pegawai,pegawai WHERE spt.nomor_spt=spt_pegawai.nomor_spt 
	AND spt_pegawai.id_pegawai=pegawai.id_pegawai AND spt.id_surat='$id' ORDER BY pegawai.id_pegawai LIMIT $posisi,$batas");
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
	 $tgl_mulai=tgl_indo($r['tgl_mulai']);	
	 $tgl_selesai=tgl_indo($r['tgl_selesai']);	

      echo "<tr><td>$no</td>
                <td>$r[nomor_spt]</td>
				<td>$r[nama]</td>
                <td>$r[uraian]</td>
				<td>$tgl_mulai s.d. $tgl_selesai</td>
				<td>$r[tempat]</td>
                <td><a href=?module=spt&act=editspt&id=$r[id_spt]><b>Edit</b></a> | 
				<a href=$aksi?module=spt&act=hapusspt&id=$r[nomor_spt]&no=$r[id_sptpeg]&srt=$r[id_surat]><b>Hapus</b></a> | 
				<a href=$cetak?id=$r[id_spt] target='_blank'><b>Cetak</b></a> | 
				<a href=?module=sppd&id=$data[id_surat]><b>SPPD</b></a></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM spt"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
     break;

 case "tambahspt":
	$id = $_GET['id'];
	$query = "SELECT * FROM surat_masuk WHERE id_surat = '$id'";
	$hasil = mysqli_query($connect,$query);
	$data = mysqli_fetch_array($hasil);
	$tgl_masuk=tgl_indo($data['tgl_masuk']);	
    echo "<h2>Tambah Surat Perintah Tugas</h2>
          <form method=POST action='$aksi?module=spt&act=inputspt' enctype='multipart/form-data'>
		  <input type=hidden name=id value=$_GET[id]>
		  <h3>Perihal Surat : $data[deskripsi]</h3>
          <table>
          <tr><td width=70>Nomor Surat</td>		<td> : <input type=text name='nomor' size=15></td></tr>
          <tr><td>Tanggal Surat</td>  			<td> : <input type=text id=datepicker name='tgl_spt' size=15></td></tr>
		  <tr><td>Dasar Surat</td>    		 	<td> <textarea name='dasar' style='width: 600px; height: 50px;'>Surat dari $data[asal_surat] Nomor $data[nomor_surat] tanggal $tgl_masuk perihal $data[deskripsi].</textarea></td></tr>
		  <tr><td>Uraian</td>  					<td> <textarea name='uraian' style='width: 600px; height: 50px;'></textarea></td></tr>
		  <tr><td>Tanggal Kegiatan</td>  		<td> : <input type=text id=tgl_mulai name='tgl_mulai' size=15> s.d. 
		  <input type=text id=tgl_selesai name='tgl_selesai' size=15></td></tr>
		  <tr><td width=70>Waktu</td>			<td> : <input type=text name='waktu' size=20></td></tr>
		  <tr><td width=70>Tempat</td>			<td> <textarea name='tempat' style='width: 600px; height: 50px;'></textarea></td></tr>
		  <tr><td width=70>Yang Diberi Tugas</td><td> : <select name='pengikut[0]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
		  <tr><td width=70>Pengikut 1</td>		<td> : <select name='pengikut[1]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr></td></tr>
		  <tr><td width=70>Pengikut 2</td>		<td> : <select name='pengikut[2]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
		  <tr><td width=70>Pengikut 3</td>		<td> : <select name='pengikut[3]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
		  <tr><td width=70>Pengikut 4</td>		<td> : <select name='pengikut[4]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
		  <tr><td width=70>Pengikut 5</td>		<td> : <select name='pengikut[5]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
		  <tr><td width=70>Pengikut 6</td>		<td> : <select name='pengikut[6]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
          <tr><td colspan=2><input type=submit class='tombol' value=Simpan>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;

  case "editspt":
    $edit = mysqli_query($connect,"SELECT * FROM spt,spt_pegawai WHERE spt.id_surat=spt_pegawai.id_surat AND spt.id_spt='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Surat Perintah Tugas</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=spt&act=update>
          <input type=hidden name=id value=$r[id_spt]>
		  <input type=hidden name=srt value=$r[id_surat]>
          <table>
          <tr><td width=70>Nomor Surat</td>		<td> : </td><td><input type=text name='nomor' size=15 value='$r[nomor_spt]'></td></tr>
          <tr><td>Tanggal Surat</td>  			<td> : </td><td><input type=text id=datepicker name='tgl_spt' value='$r[tgl_spt]' size=15></td></tr>
		  <tr><td>Dasar Surat</td>    		 	<td> : </td><td><textarea name='dasar' style='width: 600px; height: 50px;'>$r[dasar]
		  </textarea></td></tr>
		  <tr><td>Uraian</td>  					<td> : </td><td><textarea name='uraian' style='width: 600px; height: 50px;'>$r[uraian]
		  </textarea></td></tr>
		  <tr><td>Tanggal Kegiatan</td>  		<td> : </td><td><input type=text id=tgl_mulai name='tgl_mulai' value='$r[tgl_mulai]' size=15> s.d. 
		  <input type=text id=tgl_selesai name='tgl_selesai' value='$r[tgl_selesai]' size=15></td></tr>
		  <tr><td width=70>Waktu</td>			<td> : </td><td><input type=text name='waktu' value='$r[waktu]' size=20></td></tr>
		  <tr><td width=70>Tempat</td>			<td> : </td><td><textarea name='tempat' style='width: 600px; height: 50px;'>$r[tempat]
		  </textarea></td></tr>
		  <tr><td width=70>Penerima Tugas Awal</td><td> : </td><td>";
		$ta= mysqli_query($connect,"SELECT * FROM spt,spt_pegawai,pegawai WHERE spt.nomor_spt=spt_pegawai.nomor_spt 
		AND spt_pegawai.id_pegawai=pegawai.id_pegawai AND spt.id_spt='$_GET[id]' ORDER BY spt_pegawai.id_sptpeg");
    	while($z=mysqli_fetch_array($ta)){
      	echo "$z[nama] <br>";
    	}
		  echo"</td></tr>
		  <tr><td width=70>Yang Diberi Tugas *</td><td> : </td><td><select name='pengikut[0]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
		  <tr><td width=70>Pengikut 1 *</td>		<td> : </td><td><select name='pengikut[1]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr></td></tr>
		  <tr><td width=70>Pengikut 2 *</td>		<td> : </td><td><select name='pengikut[2]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
		  <tr><td width=70>Pengikut 3 *</td>		<td> : </td><td><select name='pengikut[3]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
		  <tr><td width=70>Pengikut 4 *</td>		<td> : </td><td><select name='pengikut[4]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
		  <tr><td width=70>Pengikut 5 *</td>		<td> : </td><td><select name='pengikut[5]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
		  <tr><td width=70>Pengikut 6 *</td>		<td> : </td><td><select name='pengikut[6]'>
            <option value=0 selected>- Pilih Pegawai -</option>";
            $tampil=mysqli_query($connect,"SELECT * FROM pegawai ORDER BY id_pegawai");
            while($r=mysqli_fetch_array($tampil)){
            echo "<option value=$r[id_pegawai]>$r[nama]</option>"; }
    		echo "</select></td></tr>
			<tr><td colspan=3> *) Input jika ada perubahan data pegawai yang ditugaskan.</td></tr>
            <tr><td colspan=3><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
	
}
}
?>
