<?php 
include "../../../config/koneksi.php";
include "../../../config/fungsi_indotgl.php";
include "../../../config/library.php";
include "../../../config/fungsi_romawi.php";

    $id = $_GET['id'];
	$query = "SELECT * FROM surat_masuk,spt,spt_pegawai,pegawai,sppd WHERE surat_masuk.id_surat=spt.id_surat AND spt.nomor_spt=spt_pegawai.nomor_spt 
	AND spt_pegawai.id_pegawai=pegawai.id_pegawai AND sppd.nomor_spt=spt.nomor_spt AND sppd.id_sppd = '$id'";
	$hasil = mysqli_query($connect,$query);
	$data = mysqli_fetch_array($hasil);
	
	$tgl_mulai=tgl_indo($data['tgl_mulai']);	
	$tgl_selesai=tgl_indo($data['tgl_selesai']);	
	$tgl_spt=tgl_indo($data['tgl_spt']);	
	
	$tgl=$data['tgl_spt'];
	$tg =substr($tgl,6,2);
	$tt=romawi($tg);
		
	$que = "SELECT * FROM pegawai WHERE id_pegawai = '$data[kpa]'";
	$res = mysqli_query($connect,$que);
	$f = mysqli_fetch_array($res);
?>

<html>
<head>
<style type="text/css" media="print">
	table {border: solid 1px #FFFFFF; border-collapse: collapse; width: 100%}
	tr { border: solid 1px #FFFFFF}
	td { padding: 7px 5px}
	h3 { margin-bottom: -17px }
	h2 { margin-bottom: 0px }
</style>
<style type="text/css" media="screen">
	table {border: solid 1px #FFFFFF; border-collapse: collapse; width: 60%}
	tr { border: solid 1px #FFFFFF}
	td { padding: 7px 5px}
	h3 { margin-bottom: -17px }
	h2 { margin-bottom: 0px }
</style>
</head>

<body onLoad="window.print()">
<table>
	<tr><td align="center"><img src="../../images/PND 1.png"></td><td colspan="2" align="center">
	<font size="+2">Pemerintah Kabupaten Pangandaran</font>
	<font size="+2">Badan Perencanaan Pembangunan Daerah</font><br>
	Jl. Bojongsalawe Tlp/Fax. (0265) 2641135 Parigi 46393<br>
	Email : perencanaanbappedapnd@gmail.com/ bappedapnd2013@gmail.com
	</td>
	</tr>
	
	<tr><td colspan="3" align="center" style="padding: 15px 0"><b style="font-size: 19px;"><u>Surat Perintah Tugas</u></b><br>
	Nomor : <?php echo"090/$data[nomor_spt]/Bappeda/$tt/$thn_sekarang"; ?></td></tr>
	<tr><td width="15%" valign="top"><b>Dasar</b></td><td colspan="2">: <?php echo"$data[dasar]"; ?></td></tr>
	<tr><td height="30%" colspan="3"></td></tr>
	<tr><td width="15%"><b>Nama</b></td><td colspan="2">: Drs. Ade Supriatna</td></tr>
	<tr><td width="15%"><b>Jabatan</b></td><td colspan="2">: Kepala Bappeda Kabupaten Pangandaran</td></tr>
	<tr><td height="30%" colspan="3"></td></tr>
	<tr><td width="15%" valign="top"><b>Kepada</b></td><td colspan="2">: <?php
	echo"<table>";
	$id = $_GET['id'];
    $tampil = mysqli_query($connect,"SELECT * FROM surat_masuk,spt,spt_pegawai,pegawai,sppd WHERE surat_masuk.id_surat=spt.id_surat AND 
	spt.nomor_spt=spt_pegawai.nomor_spt 
	AND spt_pegawai.id_pegawai=pegawai.id_pegawai AND sppd.nomor_spt=spt.nomor_spt AND sppd.id_sppd = '$id' ORDER BY spt_pegawai.id_sptpeg");
    while($r=mysqli_fetch_array($tampil)){
      echo "<tr><td><b>Nama</b></td><td>:</td><td>$r[nama]</td></tr>
	  <tr><td><b>NIP</b></td><td>:</td><td>$r[nip]</td></tr>
	  <tr><td><b>Jabatan</b></td><td>:</td><td>$r[jabatan]</td></tr>";
    }
    echo "</table>";?>
	</td></tr>
	<tr><td height="30%" colspan="3"></td></tr>
	<tr><td width="15%"><b>Untuk</b></td><td colspan="2">: <?php echo"$data[uraian]"; ?></td></tr>
	<tr><td></td><td width="10%"><b>Tanggal</b></td><td>: <?php echo"$data[tgl_mulai] s.d. $data[tgl_selesai]"; ?></td></tr>
	<tr><td></td><td><b>Waktu</b></td><td>: <?php echo"$data[waktu]"; ?></td></tr>
	<tr><td></td><td><b>Tempat</b></td><td>: <?php echo"$data[tempat]"; ?></td></tr>
	<tr><td height="30%" colspan="3"></td></tr>
	<tr><td colspan="3" align="justify">Demikian, untuk dilaksanakan dengan semestinya dan melaporkan hasil kegiatan tersebut.</td></tr>
	<tr><td style="height: 100px" valign="top" colspan="2">
	</td><td valign="top">
	<table width="100%" align="right"><tr><td></td><td width="50%">Ditetapkan di : Parigi<br>
	Pada tanggal  : <?php echo"$tgl_spt"; ?><br><hr width="200px" align="left">
	Kuasa Pengguna Anggaran<br>
	Bappeda Kabupaten Pangandaran,<br><br><br><br>
	
	<u><?php echo"$f[nama]"; ?></u><br>
	Pangkat : <?php echo"$f[golongan]"; ?><br>
	NIP. <?php echo"$f[nip]"; ?></td></tr></table>
	</td></tr>
</table>
</body>
</html>
