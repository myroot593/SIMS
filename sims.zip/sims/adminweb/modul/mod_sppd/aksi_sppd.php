<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus SPPD
if ($module=='sppd' AND $act=='hapussppd'){
 $sp = $_GET['sp'];
    mysqli_query($connect,"DELETE FROM sppd WHERE id_sppd='$_GET[id]'");
	
    header('location:../../media.php?module='.$module.'&id='.$sp);
}

// Input SPPD
elseif ($module=='sppd' AND $act=='inputsppd'){
    $id = $_POST['id'];
    mysqli_query($connect,"INSERT INTO sppd   (nomor_spt,
                                    biaya,
                                    kendaraan,
                                    tujuan,
                                    perdin,
									kpa) 
                            VALUES('$_POST[nomor]',
                                   '$_POST[tingkat]',
                                   '$_POST[kendaraan]',
                                   '$_POST[tujuan]',
								   '$_POST[perdin]',
								   '$_POST[kpa]')");
								   
  header('location:../../media.php?module='.$module.'&id='.$id);
}

elseif ($module=='sppd' AND $act=='update'){
 $id = $_POST['id'];
 mysqli_query($connect,"UPDATE sppd SET 	   biaya		 = '$_POST[tingkat]',
                                   kendaraan     = '$_POST[kendaraan]',
								   tujuan        = '$_POST[tujuan]',
                                   perdin        = '$_POST[perdin]',
								   kpa           = '$_POST[kpa]'
                             WHERE id_sppd       = '$_POST[sp]'");
 header('location:../../media.php?module='.$module.'&id='.$id);
}

?>
