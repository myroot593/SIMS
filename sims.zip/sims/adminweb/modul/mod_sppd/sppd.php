<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_sppd/aksi_sppd.php";
$cetak="modul/mod_sppd/cetak_sppd.php";
switch($_GET['act']){
  // Tampil SPPD
  default:
    $id = $_GET['id'];
	$query = "SELECT * FROM surat_masuk WHERE id_surat = '$id'";
	$hasil = mysqli_query($connect,$query);
	$data = mysqli_fetch_array($hasil);
	
        echo "<h2>Surat Perintah Perjalanan Dinas</h2>
          <input type=button class='tombol' value='Tambahkan Surat Perintah Perjalanan Dinas' 
		  onclick=\"window.location.href='?module=sppd&act=tambahsppd&id=$id';\">
          <h3>Perihal Surat : $data[deskripsi]</h3>
		  <table>
          <tr><th>No</th><th>Nomor SPPD</th><th>Penerima Tugas</th><th>Kegiatan</th><th>Tanggal Kegiatan</th><th>Tempat</th><th>Aksi</th>
		  </tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($connect,"SELECT * FROM spt,spt_pegawai,pegawai,sppd WHERE spt.nomor_spt=spt_pegawai.nomor_spt 
	AND spt_pegawai.id_pegawai=pegawai.id_pegawai AND spt.nomor_spt=sppd.nomor_spt ORDER BY spt.id_spt DESC LIMIT $posisi,$batas");
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
	 $tgl_mulai=tgl_indo($r['tgl_mulai']);	
	 $tgl_selesai=tgl_indo($r['tgl_selesai']);	

      echo "<tr><td>$no</td>
                <td>$r[nomor_spt]</td>
				<td>$r[nama]</td>
                <td>$r[uraian]</td>
				<td>$tgl_mulai s.d. $tgl_selesai</td>
				<td>$r[tempat]</td>
                <td><a href=?module=sppd&act=editsppd&id=$r[id_sppd]><b>Edit</b></a> | 
				<a href=$aksi?module=sppd&act=hapussppd&id=$r[id_sppd]&sp=$id><b>Hapus</b></a> | 
				<a href=$cetak?id=$r[id_sppd] target='_blank'><b>Cetak</b></a></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM sppd"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
     break;

 case "tambahsppd":
	$id = $_GET['id'];
	$query = "SELECT * FROM surat_masuk,spt,spt_pegawai,pegawai WHERE surat_masuk.id_surat=spt.id_surat AND spt.nomor_spt=spt_pegawai.nomor_spt AND 
	spt_pegawai.id_pegawai=pegawai.id_pegawai AND surat_masuk.id_surat = '$id'";
	$hasil = mysqli_query($connect,$query);
	$data = mysqli_fetch_array($hasil);
	
	$tgl_spt=tgl_indo($data['tgl_spt']);	
	$tgl_mulai=tgl_indo($data['tgl_mulai']);	
	$tgl_selesai=tgl_indo($data['tgl_selesai']);	
		
    echo "<h2>Tambah SPPD</h2>
          <form method=POST action='$aksi?module=sppd&act=inputsppd' enctype='multipart/form-data'>
		  <input type=hidden name=nomor value=$data[nomor_spt]>
		  <input type=hidden name=id value=$data[id_surat]>
		  <h3>Perihal Surat : $data[deskripsi]</h3>
          <table>
          <tr><td width=100>Nomor Surat</td>		<td> : </td><td>090/$data[nomor_spt]/Bappeda/III/2016</td></tr>
          <tr><td>Tanggal Surat</td>  			<td> : </td><td>$tgl_spt</td></tr>
		  <tr><td>Dasar Surat</td>    		 	<td> : </td><td>$data[dasar]</td></tr>
		  <tr><td>Uraian</td>  					<td> : </td><td>$data[uraian]</td></tr>
		  <tr><td>Tanggal Kegiatan</td>  		<td> : </td><td>$tgl_mulai s.d. $tgl_selesai</td></tr>
		  <tr><td>Waktu</td>			<td> : </td><td>$data[waktu]</td></tr>
		  <tr><td>Tempat</td>			<td> : </td><td>$data[tempat]</td></tr>
		  <tr><td>Yang Diberi Tugas</td><td> : </td><td>"; 
	$qu = "SELECT * FROM surat_masuk,spt,spt_pegawai,pegawai WHERE surat_masuk.id_surat=spt.id_surat AND spt.nomor_spt=spt_pegawai.nomor_spt AND 
	spt_pegawai.id_pegawai=pegawai.id_pegawai AND surat_masuk.id_surat = '$id'";
	$ha = mysqli_query($connect,$qu);
		  while( $z=mysqli_fetch_array($ha)) { echo"$z[nama] <br>"; }
		  echo"</td></tr>
		  <tr><td>Tingkat Biaya Perjalanan Dinas</td><td> : </td><td>
		  <select name='tingkat'>
            <option value=0 selected>- Pilih Tingkat Biaya -</option>";
            $t=mysqli_query($connect,"SELECT * FROM tingkat_biaya ORDER BY id_tingkat");
            while($s=mysqli_fetch_array($t)){
              echo "<option value=$s[id_tingkat]>$s[nama]</option>";
            }
    	  echo "</select></td></tr>
		  <tr><td>Jenis Angkutan</td><td> : </td><td>
		  <select name='kendaraan'>
            <option value=0 selected>- Pilih Jenis Angkutan -</option>";
            $a=mysqli_query($connect,"SELECT * FROM kendaraan ORDER BY id_kend");
            while($l=mysqli_fetch_array($a)){
              echo "<option value=$l[id_kend]>$l[nama]</option>";
            }
    	  echo "</select></td></tr>
		  <tr><td>Tujuan Keberangkatan</td><td> : </td><td><input type=text name='tujuan' size=30></td></tr>
		  <tr><td>Kuasa Pengguna Anggaran</td><td> : </td><td>
		  <select name='kpa'>
            <option value=0 selected>- Pilih KPA -</option>";
            $m=mysqli_query($connect,"SELECT * FROM pegawai WHERE status='kpa' ORDER BY id_pegawai");
            while($n=mysqli_fetch_array($m)){
              echo "<option value=$n[id_pegawai]>$n[nama]</option>";
            }
    	  echo "</select></td></tr>
		  <tr><td>Jenis Perjalanan Dinas</td><td> : </td><td> <input type=radio name='perdin' value='1' checked> Dalam Daerah &nbsp; &nbsp;
		  <input type=radio name='perdin' value='2'> Luar Daerah</td></tr>
          <tr><td colspan=3><input type=submit class='tombol' value=Simpan>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;

  case "editsppd":
	$id = $_GET['id'];
	$edit = "SELECT * FROM surat_masuk,spt,spt_pegawai,pegawai,sppd WHERE surat_masuk.id_surat=spt.id_surat AND spt.nomor_spt=spt_pegawai.nomor_spt 
	AND spt_pegawai.id_pegawai=pegawai.id_pegawai AND sppd.nomor_spt=spt.nomor_spt AND sppd.id_sppd = '$id'";
	$res = mysqli_query($connect,$edit);
	$dt = mysqli_fetch_array($res);
	
	$tgl_spt=tgl_indo($dt['tgl_spt']);	
	$tgl_mulai=tgl_indo($dt['tgl_mulai']);	
	$tgl_selesai=tgl_indo($dt['tgl_selesai']);	

    echo "<h2>Edit Surat Perintah Perjalanan Dinas</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=sppd&act=update>
          <input type=hidden name=sp value=$dt[id_sppd]>
		  <input type=hidden name=id value=$dt[id_surat]>

          <table>
          <tr><td width=100>Nomor Surat</td>	<td> : </td><td>090/$dt[nomor_spt]/Bappeda/III/2016</td></tr>
          <tr><td>Tanggal Surat</td>  			<td> : </td><td>$tgl_spt</td></tr>
		  <tr><td>Dasar Surat</td>    		 	<td> : </td><td>$dt[dasar]</td></tr>
		  <tr><td>Uraian</td>  					<td> : </td><td>$dt[uraian]</td></tr>
		  <tr><td>Tanggal Kegiatan</td>  		<td> : </td><td>$tgl_mulai s.d. $tgl_selesai</td></tr>
		  <tr><td>Waktu</td>					<td> : </td><td>$dt[waktu]</td></tr>
		  <tr><td>Tempat</td>					<td> : </td><td>$dt[tempat]</td></tr>
		  <tr><td>Yang Diberi Tugas</td><td> : </td><td>"; 
	$qu = "SELECT * FROM surat_masuk,spt,spt_pegawai,pegawai,sppd WHERE surat_masuk.id_surat=spt.id_surat AND spt.nomor_spt=spt_pegawai.nomor_spt 
	AND spt_pegawai.id_pegawai=pegawai.id_pegawai AND sppd.nomor_spt=spt.nomor_spt AND sppd.id_sppd = '$id'";
	$ha = mysqli_query($connect,$qu);
		  while($z=mysqli_fetch_array($ha)) { echo"$z[nama] <br>"; }
		  echo"</td></tr>
		  <tr><td>Tingkat Biaya Perjalanan Dinas</td>  <td> : </td><td><select name='tingkat'>";
          $tampil=mysqli_query($connect,"SELECT * FROM tingkat_biaya ORDER BY id_tingkat");
          if ($dt['biaya']==0){
            echo "<option value=0 selected>- Pilih Tingkat Biaya -</option>";
          }   
          while($w=mysqli_fetch_array($tampil)){
            if ($dt['biaya']==$w['id_tingkat']){
              echo "<option value=$w[id_tingkat] selected>$w[nama]</option>";
            }
            else{
              echo "<option value=$w[id_tingkat]>$w[nama]</option>";
            }
          }
    	echo "</select></td></tr>
		<tr><td>Jenis Angkutan</td>  <td> : </td><td><select name='kendaraan'>";
          $t=mysqli_query($connect,"SELECT * FROM kendaraan ORDER BY id_kend");
          if ($dt[biaya]==0){
            echo "<option value=0 selected>- Pilih Jenis Kendaraan -</option>";
          }   
          while($s=mysqli_fetch_array($t)){
            if ($dt[kendaraan]==$s[id_kend]){
              echo "<option value=$s[id_kend] selected>$s[nama]</option>";
            }
            else{
              echo "<option value=$s[id_kend]>$s[nama]</option>";
            }
          }
    echo "</select></td></tr>
		  <tr><td>Tujuan Keberangkatan</td>		<td> : </td><td><input type=text name='tujuan' value='$dt[tujuan]' size=50></td></tr>
		  <tr><td>Kuasa Pengguna Anggaran</td>  <td> : </td><td><select name='kpa'>";
          $z=mysqli_query($connect,"SELECT * FROM pegawai WHERE status='kpa' ORDER BY id_pegawai");
          if ($dt['kpa']==0){
            echo "<option value=0 selected>- Pilih KPA-</option>";
          }   
          while($x=mysqli_fetch_array($z)){
            if ($dt['kpa']==$x['id_pegawai']){
              echo "<option value=$x[id_pegawai] selected>$x[nama]</option>";
            }
            else{
              echo "<option value=$x[id_pegawai]>$x[nama]</option>";
            }
          }
		  $perdin=$dt['perdin'];
    echo "</select></td></tr>
		  <tr><td>Jenis Perjalanan Dinas</td><td> : </td><td> 
		  <input name='perdin' type=radio value='1'";  if($perdin=='1'){echo 'checked';}  echo" >
          Dalam Daerah &nbsp; &nbsp;  <input type='radio' name='perdin' value='2'"; if($perdin=='2'){echo 'checked';} echo" >
          Luar Daerah
		  </td></tr>
          <tr><td colspan=2><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
	
}
}
?>
