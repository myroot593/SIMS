<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";
include "../../../config/fungsi_seo.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus agenda
if ($module=='agenda' AND $act=='hapus'){
  mysqli_query($connect,"DELETE FROM agenda WHERE id_agenda='$_GET[id]'");

  header('location:../../media.php?module='.$module);
}

// Input Data agenda
elseif ($module=='agenda' AND $act=='input'){
    mysqli_query($connect,"INSERT INTO agenda (tanggal,
									judul,
                                    isi) 
                            VALUES('$tgl_sekarang',
                                   '$_POST[judul]',
								   '$_POST[isi]')");
								   
  header('location:../../media.php?module='.$module);
}

// Update agenda
elseif ($module=='agenda' AND $act=='update'){
    mysqli_query($connect,"UPDATE agenda SET judul 	   = '$_POST[judul]',
                                   isi   	   = '$_POST[isi]'
                             WHERE id_agenda = '$_POST[id]'"); 
							 
    header('location:../../media.php?module='.$module);
}
?>
