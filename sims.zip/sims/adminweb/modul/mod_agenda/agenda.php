<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_agenda/aksi_agenda.php";
switch($_GET['act']){
  // Tampil agenda
  default:
    echo "<h2>Agenda</h2>
		  <input type=button class='tombol' value='Tambahkan Agenda' 
		  onclick=\"window.location.href='?module=agenda&act=tambahagenda';\">
          <table>
          <tr><th>No</th><th>Judul</th><th>Tanggal</th><th>Aksi</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($connect,"SELECT * FROM agenda ORDER BY id_agenda DESC LIMIT $posisi,$batas");
  
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
	$tgl=tgl_indo($r['tanggal']);
      echo "<tr><td>$no</td>
                <td>$r[judul]</td>
                <td>$tgl</td>";
		        echo"<td><a href=?module=agenda&act=editagenda&id=$r[id_agenda]><b>Edit</b></a> | 
		                <a href=$aksi?module=agenda&act=hapus&id=$r[id_agenda]><b>Hapus</a></b></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM agenda"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
 
    break;
    
  case "tambahagenda":
    echo "<h2>Tambah Agenda</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=agenda&act=input>
          <table>
          <tr><td width=90>Judul</td>	<td> : </td><td><input type=text name='judul' size=50></td></tr>
		  <tr><td>Isi</td>     			<td> : </td><td><textarea name='isi' style='width: 600px; height: 350px;'></textarea></td></tr>
		  <tr><td colspan=3><input type=submit class='tombol' value=Simpan>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
	
  case "editagenda":
    $edit = mysqli_query($connect,"SELECT * FROM agenda WHERE id_agenda='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Agenda</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=agenda&act=update>
          <input type=hidden name='id' value='$r[id_agenda]'>
          <table>
          <tr><td width=90>Judul</td>	<td> : </td><td><input type=text name='judul' size=50 value='$r[judul]'></td></tr>
		  <tr><td>Isi</td>     			<td> : </td><td><textarea name='isi' style='width: 600px; height: 350px;'>$r[isi]</textarea></td></tr>
		  <tr><td colspan=3><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
}
}
?>
