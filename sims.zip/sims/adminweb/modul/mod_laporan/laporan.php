<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
   echo "<h2>Agenda Surat Masuk</h2>
          <form method=POST action='modul/mod_laporan/report.php'  target='_blank'>
          <table>
          <tr><td width=100px>Dari Tanggal</td><td> : <input type=text id=tgl_mulai name='tgl_mulai' size=10>     
		  </td></tr>
          <tr><td>s/d Tanggal</td><td> : <input type=text id=tgl_selesai name='tgl_selesai' size=10>
		  </td></tr>
          <tr><td colspan=2><input type=submit class=tombol value=Proses>
          <input type=button class=tombol value=Batal onclick=self.history.back()></td></tr>
          </table>
          </form>";
    break;

}
?>
