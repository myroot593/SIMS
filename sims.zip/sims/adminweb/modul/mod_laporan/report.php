<html>
<head>
<style type="text/css" media="print">
	table {border: solid 1px #000; border-collapse: collapse; width: 100%}
	tr { border: solid 1px #000; page-break-inside: avoid;}
	td { padding: 7px 5px; font-size: 10px}
	th {
		font-family:Arial;
		color:black;
		font-size: 11px;
		background-color:lightgrey;
	}
	thead {
		display:table-header-group;
	}
	tbody {
		display:table-row-group;
	}
	h3 { margin-bottom: -17px }
	h2 { margin-bottom: 0px }
</style>
<style type="text/css" media="screen">
	table {border: solid 1px #000; border-collapse: collapse; width: 100%}
	tr { border: solid 1px #000}
	th {
		font-family:Arial;
		color:black;
		font-size: 11px;
		background-color: #999;
		padding: 8px 0;
	}
	td { padding: 7px 5px;font-size: 10px}
	h3 { margin-bottom: -17px }
	h2 { margin-bottom: 0px }
</style>
<title>Cetak Agenda Surat Masuk</title>
</head>
<body onLoad="window.print()">

<?php
include "../../../config/koneksi.php";
include "../../../config/fungsi_indotgl.php";
include "../../../config/library.php";
		
$mulai=tgl_indo($_POST['tgl_mulai']); 
$selesai=tgl_indo($_POST['tgl_selesai']); ?>

	<center><b style="font-size: 20px">AGENDA SURAT MASUK</b><br>
	Dari tanggal :<b> <?php echo"$mulai"; ?></b> sampai dengan tanggal<b> <?php echo"$selesai"; ?>.</b>
	</center><br>
	
	<table>
		<thead>
			<tr>
				<th width="3%">No</td>
				<th width="5%">Indeks Surat</td>
				<th width="8%">Nomor Register</td>
				<th width="8%">Tanggal Register</td>
				<th width="18%">Perihal</td>
				<th width="17%">Asal Surat</td>
				<th width="7%">Nomor Surat</td>
				<th width="10%">Tanggal Surat</td>
				<th width="19%">Keterangan</td>
				<th width="5%">Paraf</td>
			</tr>
		</thead>
		<tbody>
<?php
$sql = mysqli_query($connect,"SELECT * FROM surat_masuk  
                    WHERE tgl_register BETWEEN '$_POST[tgl_mulai]' AND '$_POST[tgl_selesai]'");
$jml = mysqli_num_rows($sql);

if ($jml >= 1){
$i = 1;
while($r = mysqli_fetch_array($sql)){
$reg=tgl_indo($r['tgl_register']);
$msk=tgl_indo($r['tgl_masuk']);

			    echo"<tr align=center>
				<td>$i</td>
				<td>$r[indeks]</td>
				<td>$r[register]</td>
				<td>$reg</td>
				<td>$r[deskripsi]</td>
				<td>$r[asal_surat]</td>
				<td>$r[nomor_surat]</td>
				<td>$msk</td>
				<td>$r[keterangan]</td>
				<td></td>
			</tr>";
  $i++;
    echo"</tbody>
	</table>"; ?>  

 
<?php
}}
		
echo"</body>
</html>";     ?>