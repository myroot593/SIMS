<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_member/aksi_member.php";
switch($_GET['act']){
  // Tampil Member
  default:
    echo "<h2>Data User</h2>
          <table>
          <tr><th>No</th><th>Nama Lengkap</th><th>Alamat</th><th>Email</th><th>No Telepon</th><th>Aksi</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($connect,"SELECT * FROM member ORDER BY id_member DESC LIMIT $posisi,$batas");
  
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
	
      echo "<tr><td>$no</td>
                <td>$r[nama_lengkap]</td>
                <td>$r[alamat]</td>
                <td>$r[email]</td>
				<td>$r[no_telp]</td>";
		        echo"<td><a href=?module=member&act=editmember&id=$r[id_member]><b>Edit</b></a> | 
		                <a href=$aksi?module=member&act=hapus&id=$r[id_member]><b>Hapus</a></b></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM member"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
 
    break;
    
  case "editmember":
    $edit = mysqli_query($connect,"SELECT * FROM member WHERE id_member='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Data Member</h2>
          <form method=POST action=$aksi?module=member&act=update>
          <input type=hidden name='id' value='$r[id_member]'>
          <table>
          <tr><td width=90>Nama Lengkap</td><td> : <input type=text name='nama_lengkap' size=40 value='$r[nama_lengkap]'></td></tr>
		  <tr><td>Alamat</td>     <td> : <input type=text name='alamat' size=100 value='$r[alamat]'></td></tr>
          <tr><td>Email</td>     <td> : <input type=text name='email' size=40 value='$r[email]'></td></tr>
		  <tr><td>No Telepon</td>     <td> : <input type=text name='telp' size=40 value='$r[no_telp]'></td></tr>
          <tr><td colspan=2><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
}
}
?>
