<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";
include "../../../config/fungsi_seo.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus member
if ($module=='member' AND $act=='hapus'){
  mysqli_query($connect,"DELETE FROM member WHERE id_member='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Update member
elseif ($module=='member' AND $act=='update'){
    mysqli_query($connect,"UPDATE member SET nama_lengkap = '$_POST[nama_lengkap]',
                                   alamat  	   = '$_POST[alamat]',
                                   email 	   = '$_POST[email]',
                                   no_telp     = '$_POST[telp]'
                             WHERE id_member = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
}
?>
