<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus Surat
if ($module=='dokumen' AND $act=='hapus'){
  $id = $_GET['id'];
  $query = "SELECT * FROM dokumen WHERE id_dok = '$id'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFile = $data['file']; 
  mysqli_query($connect,"DELETE FROM dokumen WHERE id_dok='$_GET[id]'");
  unlink("../../upload/dokumen/".$namaFile);
  header('location:../../media.php?module='.$module);
}

// Input Surat Masuk
elseif ($module=='dokumen' AND $act=='input'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  // Apabila ada file yang diupload
  if (!empty($lokasi_file)){
    UploadDok($nama_file_unik);
    mysqli_query($connect,"INSERT INTO dokumen(judul,
									keterangan,
									tanggal,
									file) 
                            VALUES('$_POST[judul]',
							       '$_POST[keterangan]',
								   '$tgl_sekarang',
                                   '$nama_file_unik')");
  }
  else{
    mysqli_query($connect,"INSERT INTO dokumen (judul,
									keterangan,
									tanggal)
                            VALUES('$_POST[judul]',
							       '$_POST[keterangan]',
								   '$tgl_sekarang')");
  }
  header('location:../../media.php?module='.$module);
}

// Update Surat Masuk
elseif ($module=='dokumen' AND $act=='update'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  $query = "SELECT * FROM dokumen WHERE id_dok = '$_POST[id]'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFilex = $data['file'];
  
  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
    mysqli_query($connect,"UPDATE dokumen SET judul = '$_POST[judul]',
								   keterangan     = '$_POST[keterangan]'
                             WHERE id_dok   = '$_POST[id]'");
  }
  else{
    UploadDok($nama_file_unik);
    mysqli_query($connect,"UPDATE dokumen SET judul		    = '$_POST[judul]',
								   keterangan	 	= '$_POST[keterangan]',
                                   file      		= '$nama_file_unik'   
                             WHERE id_dok   = '$_POST[id]'");
 
  unlink("../../upload/dokumen/".$namaFilex);
  }
  header('location:../../media.php?module='.$module);
}

// Download Surat
elseif ($module=='download'){
$id = $_GET['id'];
$query = "SELECT * FROM dokumen WHERE id_dok = '$id'";
$hasil = mysqli_query($connect,$query);
$data = mysqli_fetch_array($hasil);

header("Content-Disposition: attachment; filename=".$data['file']);
header("Content-length: ".$data['size']);
header("Content-type: ".$data['type']);
$fp = fopen("../../upload/dokumen/".$data['file'], 'r');
$content = fread($fp, filesize('../../upload/dokumen/'.$data['file']));
fclose($fp);
echo $content;
exit; 
}

?>
