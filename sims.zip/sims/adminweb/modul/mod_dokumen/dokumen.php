<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_dokumen/aksi_dokumen.php";

switch($_GET['act']){
  // Tampil Surat Masuk
  default:
    echo "<h2>Dokumen Perencanaan</h2>
          <input type=button class='tombol' value='Tambahkan Dokumen Perencanaan' onclick=\"window.location.href='?module=dokumen&act=tambahdokumen';\">
          <table>
          <tr><th>No</th><th>Judul</th><th>Keterangan</th><th>File</th><th>Aksi</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($connect,"SELECT * FROM dokumen ORDER BY id_dok DESC LIMIT $posisi,$batas");
      
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
	  
      echo "<tr><td>$no</td>
	  			<td>$r[judul]</td>
                <td>$r[keterangan]</td>
				<td><a href='$aksi?module=download&id=".$r['id_dok']."'>Download</a></td>
                <td><a href=?module=dokumen&act=editdokumen&id=$r[id_dok]><b>Edit</b></a> | 
				<a href=$aksi?module=dokumen&act=hapus&id=$r[id_surat]><b>Hapus</a></b></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM dokumen"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
 
    break;
  
  case "tambahdokumen":
    echo "<h2>Tambah Dokumen Perencanaan</h2>
          <form method=POST action='$aksi?module=dokumen&act=input' enctype='multipart/form-data'>
          <table>
          <tr><td>Judul</td>     				<td> : </td><td><input type=text name='judul' size=60></td></tr>
          <tr><td>Keterangan</td>    		 	<td> : </td><td><input type=text name='keterangan' size=60></td></tr>
          <tr><td>File</td>      				<td> : </td><td><input type=file name='fupload' size=40> 
          <tr><td colspan=3><input type=submit class='tombol' value=Simpan>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;
    
  case "editdokumen":
    $edit = mysqli_query($connect,"SELECT * FROM dokumen WHERE id_dok='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Dokumen Perencanaan</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=dokumen&act=update>
          <input type=hidden name=id value=$r[id_dok]>
          <table>
		  <tr><td>Judul</td>		<td> : </td><td><input type=text name='judul' size=60 value='$r[judul]'></td></tr>
		  <tr><td>Keterangan</td>   <td> : </td><td><input type=text name='keterangan' value='$r[keterangan]' size=60></td></tr>
          <tr><td>Ganti File</td>   <td> : </td><td><input type=file name='fupload' size=40> *)</td></tr>
          <tr><td colspan=3>*) Apabila file tidak diubah, dikosongkan saja.</td></tr>
          <tr><td colspan=3><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
}
}
?>
