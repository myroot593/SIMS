<?php
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus banner
if ($module=='link' AND $act=='hapus'){
  $query = "SELECT * FROM mod_bank WHERE id_bank = '$_GET[id]'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFilex = $data['gambar'];
  
  mysqli_query($connect,"DELETE FROM mod_bank WHERE id_bank='$_GET[id]'");
  unlink("../foto_banner/".$namaFilex);
  
  header('location:../../media.php?module='.$module);
}

// Input bank
elseif ($module=='link' AND $act=='input'){
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];

  // Apabila ada gambar yang diupload
  if (!empty($lokasi_file)){
    UploadBanner($nama_file);
    mysqli_query($connect,"INSERT INTO mod_bank(nama_bank,
                                    no_rekening,
                                    pemilik,
                                    gambar) 
                            VALUES('$_POST[nama_bank]',
                                   '$_POST[no_rekening]',
                                   '$_POST[pemilik]',
                                   '$nama_file')");
  }
  else{
    mysqli_query($connect,"INSERT INTO mod_bank(nama_bank,
                                    no_rekening,
                                    pemilik) 
                            VALUES($_POST[nama_bank]',
                                   '$_POST[no_rekening]',
                                   '$_POST[pemilik]')");
  }
  header('location:../../media.php?module='.$module);
}

// Update banner
elseif ($module=='link' AND $act=='update'){
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];

  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
    mysqli_query($connect,"UPDATE mod_bank SET nama_bank     = '$_POST[nama_bank]',
                                   no_rekening       = '$_POST[no_rekening]',
                                   pemilik       = '$_POST[pemilik]'                                   
                             WHERE id_bank = '$_POST[id]'");
  }
  else{
    UploadBanner($nama_file);
    mysqli_query($connect,"UPDATE mod_bank SET nama_bank     = '$_POST[nama_bank]',
                                   no_rekening       = '$_POST[no_rekening]',
                                   pemilik       = '$_POST[pemilik]',
                                   gambar       = '$nama_file'
                             WHERE id_bank = '$_POST[id]'");
  }
  header('location:../../media.php?module='.$module);
}
?>
