<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_masuk/aksi_masuk.php";
switch($_GET['act']){
  // Tampil Surat Masuk
  default:
  echo "<h2>Cari Surat</h2>
          <form method=POST action='?module=search&act=cari' enctype='multipart/form-data'>
          <table>
		  <tr><td>Kata Kunci</td>  		<td> : </td><td><input type=text name='kata' size=60></td></tr>
          <tr><td>Jenis Surat</td>  	<td> : </td><td>
          <select name='jenis'>
          <option value=0 selected>- Jenis Surat -</option>
          <option value=masuk>Surat Masuk</option><option value=keluar>Surat Keluar</option>
    	  </select></td></tr>
          <tr><td colspan=3><input type=submit class='tombol' value=Cari></td></tr>
          </table></form>";
    break;
  
  case "cari":
    if(($_POST['jenis'] == 'masuk') AND ($_POST['kata'] <> "")) {
    echo "<h2>Hasil Pencarian Surat Masuk</h2>
          <table>
          <tr><th>No</th><th>Tanggal Register</th><th>Nomor Surat</th><th>Asal Surat</th><th>Tanggal Surat</th><th>Perihal</th><th>File</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

	$kunci = $_POST['kata'];
  	$kunci = strip_tags($kunci); $kunci=mysql_real_escape_string($kunci);
  	$kunci=ltrim($kunci);
	$kunci=rtrim($kunci);
	$kt=split(" ",$kunci);
	while(list($key,$val)=each($kt)){
	if($val<>" " and strlen($val) > 0){$q .= " deskripsi LIKE '%$val%' or ";}	} 
	$q=substr($q,0,(strLen($q)-3));
	$query="SELECT * FROM surat_masuk WHERE $q ";
 	$sql = mysqli_query($connect,$query);
	$jumlah = mysqli_num_rows($sql); 
  	if ($jumlah > 0) {
    $no = $posisi+1;
    while ($r=mysqli_fetch_array($sql)) {
      $reg=tgl_indo($r['tgl_register']);
	  $tgl=tgl_indo($r['tgl_masuk']);
	  
      echo "<tr><td>$no</td>
	  			<td>$reg</td>
                <td>$r[nomor_surat]</td>
                <td>$r[asal_surat]</td>
				<td>$tgl</td><td>";
		$kalimat=strtok(nl2br($r['deskripsi'])," ");
				for ($s=1;$s<=10;$s++){
      echo ($kalimat);
      echo (" "); // Spasi antar kalimat
      $kalimat=strtok(" "); // Potong per kalimat
      } 				
				echo"....</td><td><a href='$aksi?module=download&id=".$r['id_surat']."'>Download</a></td></tr>";
      $no++;
    }}
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM surat_masuk"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
	}
	
	elseif (($_POST['jenis'] == 'keluar') AND ($_POST['kata'] <> "")) {
	    echo "<h2>Hasil Pencarian Surat Keluar</h2>
          <table>
          <tr><th>No</th><th>Nomor Surat</th><th>Tujuan Surat</th><th>Tanggal Surat</th><th>Perihal</th><th>File</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

	$kunci = $_POST['kata'];
  	$kunci = strip_tags($kunci); $kunci=mysql_real_escape_string($kunci);
  	$kunci=ltrim($kunci);
	$kunci=rtrim($kunci);
	$kt=split(" ",$kunci);
	while(list($key,$val)=each($kt)){
	if($val<>" " and strlen($val) > 0){$q .= " deskripsi LIKE '%$val%' or ";}	} 
	$q=substr($q,0,(strLen($q)-3));
	$query="SELECT * FROM surat_keluar WHERE $q ";
 	$sql = mysqli_query($connect,$query);
	$jumlah = mysqli_num_rows($sql); 
  	if ($jumlah > 0) {
    $no = $posisi+1;
    while ($r=mysqli_fetch_array($sql)) {
      $tanggal=tgl_indo($r['tgl_keluar']);
      echo "<tr><td>$no</td>
                <td>$r[indeks]/$r[register]/Bappeda/2016</td>
                <td>$r[tujuan]</td>
				<td>$r[tgl_keluar]</td><td>";
		$kalimat=strtok(nl2br($r['deskripsi'])," ");
				for ($s=1;$s<=10;$s++){
      echo ($kalimat);
      echo (" "); // Spasi antar kalimat
      $kalimat=strtok(" "); // Potong per kalimat
      } 				
				echo"....</td><td><a href='$aksi?module=download&id=".$r['id_surat']."'>Download</a></td></tr>";
      $no++;
    }}
    echo "<tr><td colspan=6><input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr></table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM surat_keluar"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
	}
	
	else { echo"<script>alert('Kata kunci atau jenis surat belum dimasukkan, silakan ulangi kembali!'); window.location = '?module=search'</script>"; }
	
	break;
}}
?>
