<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/fungsi_seo.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus Kategori
if ($module=='kategori' AND $act=='hapus'){
  mysqli_query($connect,"DELETE FROM kategori WHERE id_kategori='$_GET[id]'");
  header('location:../../media.php?module='.$module);
}

// Input kategori
elseif ($module=='kategori' AND $act=='input'){
  mysqli_query($connect,"INSERT INTO kategori(indeks, nama_kategori) VALUES('$_POST[indeks]','$_POST[nama_kategori]')");
  header('location:../../media.php?module='.$module);
}

// Update kategori
elseif ($module=='kategori' AND $act=='update'){
  $kategori_seo = seo_title($_POST['nama_kategori']);
  mysqli_query($connect,"UPDATE kategori SET indeks = '$_POST[indeks]',nama_kategori = '$_POST[nama_kategori]' WHERE id_kategori = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
}
?>
