<?php
$aksi="modul/mod_kategori/aksi_kategori.php";
switch($_GET['act']){
  // Tampil Kategori
  default:
    echo "<h2>Indeks Surat</h2>
          <input type=button class='tombol' value='Tambah Indeks Surat' 
          onclick=\"window.location.href='?module=kategori&act=tambahkategori';\">
          <table>
          <tr><th>No</th><th>Indeks Surat</th><th>Keterangan</th><th>Aksi</th></tr>"; 
    $tampil=mysqli_query($connect,"SELECT * FROM kategori ORDER BY id_kategori DESC");
    $no=1;
    while ($r=mysqli_fetch_array($tampil)){
       echo "<tr><td>$no</td>
	   		<td>$r[indeks]</td>
			<td>$r[nama_kategori]</td>
            <td><a href=?module=kategori&act=editkategori&id=$r[id_kategori]><b>Edit</b></a> | 
	               <a href=$aksi?module=kategori&act=hapus&id=$r[id_kategori]><b>Hapus</b></a>
             </td></tr>";
      $no++;
    }
    echo "</table>";
    break;
  
  // Form Tambah Kategori
  case "tambahkategori":
    echo "<h2>Tambah Indeks Surat</h2>
          <form method=POST action='$aksi?module=kategori&act=input'>
          <table>
          <tr><td>Indeks Surat</td><td> : <input type=text name='indeks'></td></tr>
		  <tr><td>Keterangan</td><td> : <input type=text name='nama_kategori'></td></tr>
          <tr><td colspan=2><input type=submit name=submit class='tombol'  value=Simpan>
                            <input type=button class='tombol'  value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
     break;
  
  // Form Edit Kategori  
  case "editkategori":
    $edit=mysqli_query($connect,"SELECT * FROM kategori WHERE id_kategori='$_GET[id]'");
    $r=mysqli_fetch_array($edit);

    echo "<h2>Edit Indeks Surat</h2>
          <form method=POST action=$aksi?module=kategori&act=update>
          <input type=hidden name=id value='$r[id_kategori]'>
          <table>
		  <tr><td>Indeks</td><td> : </td><td><input type=text name='indeks' value='$r[indeks]'></td></tr>
          <tr><td>Nama</td><td> : </td><td><input type=text name='nama_kategori' value='$r[nama_kategori]'></td></tr>
		  <tr><td colspan=2></td><td><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
          </table></form>";
    break;  
}
?>
