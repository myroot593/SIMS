<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Update profil
if ($module=='welcome' AND $act=='update'){
  mysqli_query($connect,"UPDATE modul SET static_content = '$_POST[isi]' WHERE id_modul = '$_POST[id]'");
  header('location:../../media.php?module='.$module);
}
?>
