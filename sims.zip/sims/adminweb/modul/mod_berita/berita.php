<?php
session_start();
 if (empty($_SESSION['user']) AND empty($_SESSION['pass'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_berita/aksi_berita.php";
switch($_GET['act']){
  // Tampil berita
  default:
    echo "<h2>Berita</h2>
		  <input type=button class='tombol' value='Tambahkan Data Berita' 
		  onclick=\"window.location.href='?module=berita&act=tambahberita';\">
          <table>
          <tr><th>No</th><th>Judul Berita</th><th>Penulis</th><th>Sumber</th><th>Jam/ Tanggal</th><th>Aksi</th></tr>";

    $p      = new Paging;
    $batas  = 10;
    $posisi = $p->cariPosisi($batas);

    $tampil = mysqli_query($connect,"SELECT * FROM berita ORDER BY id_berita DESC LIMIT $posisi,$batas");
  
    $no = $posisi+1;
    while($r=mysqli_fetch_array($tampil)){
	$tgl=tgl_indo($r['tanggal']);
      echo "<tr><td>$no</td>
                <td>$r[judul]</td>
                <td>$r[penulis]</td>
                <td>$r[sumber]</td>
				<td>$r[jam]/ $tgl</td>";
		        echo"<td><a href=?module=berita&act=editberita&id=$r[id_berita]><b>Edit</b></a> | 
		                <a href=$aksi?module=berita&act=hapus&id=$r[id_berita]><b>Hapus</a></b></td>
		        </tr>";
      $no++;
    }
    echo "</table>";

    $jmldata = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM berita"));
    $jmlhalaman  = $p->jumlahHalaman($jmldata, $batas);
    $linkHalaman = $p->navHalaman($_GET['halaman'], $jmlhalaman);

    echo "<div id=paging>Hal: $linkHalaman</div><br>";
 
    break;
    
  case "tambahberita":
    echo "<h2>Tambah Berita</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=berita&act=input>
		  <input type=hidden name='nama' value='$_SESSION[nama]'>
          <table>
          <tr><td width=90>Judul</td>	<td> : </td><td><input type=text name='judul' size=50></td></tr>
		  <tr><td>Isi</td>     			<td> : </td><td><textarea name='isi' style='width: 600px; height: 350px;'></textarea></td></tr>
		  <tr><td width=90>Sumber</td>	<td> : </td><td><input type=text name='sumber' size=50></td></tr>
		  <tr><td>File</td>      		<td> : </td><td><input type=file name='fupload' size=40></td></tr> 
          <tr><td colspan=3><input type=submit class='tombol' value=Simpan>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
	
  case "editberita":
    $edit = mysqli_query($connect,"SELECT * FROM berita WHERE id_berita='$_GET[id]'");
    $r    = mysqli_fetch_array($edit);

    echo "<h2>Edit Berita</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=berita&act=update>
          <input type=hidden name='id' value='$r[id_berita]'>
          <table>
          <tr><td width=90>Judul</td>	<td> : </td><td><input type=text name='judul' size=50 value='$r[judul]'></td></tr>
		  <tr><td>Isi</td>     			<td> : </td><td><textarea name='isi' style='width: 600px; height: 350px;'>$r[isi_berita]</textarea></td></tr>
		  <tr><td width=90>Sumber</td>	<td> : </td><td><input type=text name='sumber' size=50 value='$r[sumber]'></td></tr>
		  <tr><td>File</td>      		<td> : </td><td><input type=file name='fupload' size=40> 
          <tr><td colspan=3><input type=submit class='tombol' value=Update>
                            <input type=button class='tombol' value=Batal onclick=self.history.back()></td></tr>
         </table></form>";
    break;  
}
}
?>
