<?php
session_start();
include "../../../config/koneksi.php";
include "../../../config/library.php";
include "../../../config/fungsi_thumb.php";
include "../../../config/fungsi_seo.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Hapus Pegawai
if ($module=='berita' AND $act=='hapus'){
  $query = "SELECT * FROM berita WHERE id_berita = '$_GET[id]'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFilex = $data['gambar'];
  
  mysqli_query($connect,"DELETE FROM berita WHERE id_berita='$_GET[id]'");
  unlink("../../foto_berita/".$namaFilex);
  unlink("../../foto_berita/small_".$namaFilex);
  header('location:../../media.php?module='.$module);
}

// Input Data Pegawai
elseif ($module=='berita' AND $act=='input'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 
if (!empty($lokasi_file)){
	UploadBerita($nama_file_unik);
    mysqli_query($connect,"INSERT INTO berita (judul,
                                    penulis,
                                    tanggal,
                                    jam,
                                    isi_berita,
									sumber,
									gambar) 
                            VALUES('$_POST[judul]',
                                   '$_POST[nama]',
                                   '$tgl_sekarang',
                                   '$jam_sekarang',
								   '$_POST[isi]',
								   '$_POST[sumber]',
								   '$nama_file_unik')"); }
else {
    mysqli_query($connect,"INSERT INTO berita (judul,
                                    penulis,
                                    tanggal,
                                    jam,
                                    isi_berita,
									sumber) 
                            VALUES('$_POST[judul]',
                                   '$_POST[nama]',
                                   '$tgl_sekarang',
                                   '$jam_sekarang',
								   '$_POST[isi]',
								   '$_POST[sumber]')"); }
  header('location:../../media.php?module='.$module);
}

// Update Berita
elseif ($module=='berita' AND $act=='update'){
  $lokasi_file    = $_FILES['fupload']['tmp_name'];
  $tipe_file      = $_FILES['fupload']['type'];
  $nama_file      = $_FILES['fupload']['name'];
  $acak           = rand(1,99);
  $nama_file_unik = $acak.$nama_file; 

  $query = "SELECT * FROM berita WHERE id_berita = '$_POST[id]'";
  $hasil = mysqli_query($connect,$query);
  $data = mysqli_fetch_array($hasil);
  $namaFilex = $data['gambar'];

  // Apabila gambar tidak diganti
  if (empty($lokasi_file)){
    mysqli_query($connect,"UPDATE berita SET judul 	   = '$_POST[judul]',
                                   isi_berita  = '$_POST[isi]',
								   sumber  = '$_POST[sumber]'
                             WHERE id_berita = '$_POST[id]'"); }
  else {
    UploadBerita($nama_file_unik);
	mysqli_query($connect,"UPDATE berita SET judul 	   = '$_POST[judul]',
                                   isi_berita  = '$_POST[isi]',
								   gambar      =  '$nama_file_unik',
								   sumber  = '$_POST[sumber]' 
                             WHERE id_berita = '$_POST[id]'"); 
  unlink("../../foto_berita/".$namaFilex);
  unlink("../../foto_berita/small_".$namaFilex);   }
  header('location:../../media.php?module='.$module);
}
?>
