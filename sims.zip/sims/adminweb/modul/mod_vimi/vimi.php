<?php
$aksi="modul/mod_vimi/aksi_vimi.php";
switch($_GET['act']){
  // Tampil Profil
  default:
    $sql  = mysqli_query($connect,"SELECT * FROM modul WHERE id_modul='56'");
    $r    = mysqli_fetch_array($sql);

    echo "<h2>Edit Visi &amp; Misi</h2>
          <form method=POST enctype='multipart/form-data' action=$aksi?module=vimi&act=update>
          <input type=hidden name=id value=$r[id_modul]>
          <table>
      
         <tr><td><textarea name='isi' style='width: 600px; height: 350px;'>$r[static_content]</textarea></td></tr>
         <tr><td><input type=submit class=tombol value=Update></td></tr>
         </form></table>";
    break;  
}
?>
