<?php
include "../config/koneksi.php";

if ($_SESSION['level']=='admin'){

echo "<li><a href='?module=kategori'><b>Indeks Surat</b></a></li>"; 
echo "<li><a href='?module=masuk'><b>Surat Masuk</b></a></li>"; 
echo "<li><a href='?module=keluar'><b>Surat Keluar</b></a></li>"; 
echo "<li><a href='?module=search'><b>Cari Surat</b></a></li>";
echo "<li><a href='?module=member'><b>Data User</b></a></li>";
echo "<li><a href='?module=pegawai'><b>Data Pegawai</b></a></li>";
echo "<li><a href='?module=hubungi'><b>Pesan Masuk</b></a></li>"; 
echo "<li><a href='?module=laporan'><b>Agenda Surat Masuk</b></a></li>";   
echo "<li><a href='?module=laporan2'><b>Agenda Surat Keluar</b></a></li>";
echo "<li><a href='?module=poling'><b>Polling</b></a></li>";
} 
else { 
echo "<li><a href='?module=kategori'><b>Tambah Indeks Surat</b></a></li>"; 
echo "<li><a href='?module=masuk'><b>Tambah Surat Masuk</b></a></li>"; 
echo "<li><a href='?module=keluar'><b>Tambah Surat Keluar</b></a></li>"; 
echo "<li><a href='?module=search'><b>Cari Surat</b></a></li>";
echo "<li><a href='?module=laporan'><b>Lihat Agenda Surat Masuk</b></a></li>";   
echo "<li><a href='?module=laporan2'><b>Lihat Agenda Surat Keluar</b></a></li>";
}
?>
