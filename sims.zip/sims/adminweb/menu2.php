<?php
include "../config/koneksi.php";

if ($_SESSION['level']=='admin'){

    echo "<li><a href='?module=link'><b>Edit Link Terkait</b></a></li>";
	echo "<li><a href='?module=berita'><b>Edit Berita</b></a></li>";
	echo "<li><a href='?module=agenda'><b>Edit Agenda</b></a></li>";
	echo "<li><a href='?module=dokumen'><b>Edit Dokumen Perencanaan</b></a></li>";
    echo "<li><a href='?module=menuutama'><b>Edit Menu Utama</b></a></li>";
	echo "<li><a href='?module=submenu'><b>Edit Sub Menu</b></a></li>";
	echo "<li><a href='?module=profil'><b>Edit Profil</b></a></li>"; 
	echo "<li><a href='?module=vimi'><b>Edit Visi &amp; Misi</b></a></li>"; 
	echo "<li><a href='?module=tupoksi'><b>Edit Tupoksi</b></a></li>"; 
	echo "<li><a href='?module=struktur'><b>Edit Struktur Organisasi</b></a></li>"; 
	echo "<li><a href='?module=welcome'><b>Edit Selamat Datang</b></a></li>"; 
	echo "<li><a href='?module=banner'><b>Edit Banner</b></a></li>"; 
//	echo "<li><a href='?module=sekilasinfo'><b>Edit Sekilas Info</b></a></li>"; 

}

else {
	echo "<li><a href='?module=berita'><b>Edit Berita</b></a></li>";
	echo "<li><a href='?module=agenda'><b>Edit Agenda</b></a></li>";
	echo "<li><a href='?module=banner'><b>Edit Banner</b></a></li>"; 
//	echo "<li><a href='?module=sekilasinfo'><b>Edit Sekilas Info</b></a></li>"; 
}

?>
