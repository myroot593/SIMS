<?php
include "../config/koneksi.php";

if ($_SESSION['level']=='admin'){
    echo "<li><a href='?module=password'><b>Ganti Password</b></a></li>";
    echo "<li><a href='?module=modul'><b>Edit Modul Admin</b></a></li>"; 
}
else {
    echo "<li><a href='?module=password'><b>Ganti Password</b></a></li>";
}
?>
