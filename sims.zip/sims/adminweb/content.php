<?php
include "../config/koneksi.php";
include "../config/library.php";
include "../config/fungsi_indotgl.php";
include "../config/fungsi_combobox.php";
include "../config/class_paging.php";
include "../config/fungsi_rupiah.php";
include "../config/fungsi_romawi.php";

// Bagian Home
if ($_GET['module']=='home'){
  if ($_SESSION['level']=='admin' or 'user'){
  echo "<h2>Selamat Datang</h2>
          <p>Hai <b>$_SESSION[nama]</b>, selamat datang di halaman administrator Sistem Informasi Manajemen Surat (SIMS) Bappeda Kabupaten Pangandaran.<br> Silahkan klik menu pilihan yang berada di sebelah kiri untuk mengelola konten website. </p>
          <p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>
          <p align=right>Login : $hari_ini, ";
  echo tgl_indo(date("Y m d")); 
  echo " | "; 
  echo date("H:i:s");
  echo " WIB</p>";
  }
}

// Bagian Modul
elseif ($_GET['module']=='modul'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_modul/modul.php";
  }
}

// Bagian Kategori
elseif ($_GET['module']=='kategori'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_kategori/kategori.php";
  }
}

// Bagian Surat Masuk
elseif ($_GET['module']=='masuk'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_masuk/masuk.php";
  }
}

// Bagian Surat Masuk
elseif ($_GET['module']=='keluar'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_keluar/keluar.php";
  }
}

// Bagian Disposisi
elseif ($_GET['module']=='disposisi'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_disposisi/disposisi.php";
  }
}

// Bagian SPT
elseif ($_GET['module']=='spt'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_spt/spt.php";
  }
}

// Bagian SPPD
elseif ($_GET['module']=='sppd'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_sppd/sppd.php";
  }
}

// Bagian Data Pegawai
elseif ($_GET['module']=='pegawai'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_pegawai/pegawai.php";
  }
}

// Bagian Berita
elseif ($_GET['module']=='berita'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_berita/berita.php";
  }
}

// Bagian Agenda
elseif ($_GET['module']=='agenda'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_agenda/agenda.php";
  }
}

// Bagian Dokumen
elseif ($_GET['module']=='dokumen'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_dokumen/dokumen.php";
  }
}

// Bagian Member
elseif ($_GET['module']=='member'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_member/member.php";
  }
}

// Bagian Profil
elseif ($_GET['module']=='profil'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_profil/profil.php";
  }
}

// Bagian Visi & Misi
elseif ($_GET['module']=='vimi'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_vimi/vimi.php";
  }
}

// Bagian Tupoksi
elseif ($_GET['module']=='tupoksi'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_tupoksi/tupoksi.php";
  }
}

// Bagian Struktur Organisasi
elseif ($_GET['module']=='struktur'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_struktur/struktur.php";
  }
}

// Bagian Hubungi
elseif ($_GET['module']=='hubungi'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_hubungi/hubungi.php";
  }
}

// Modul link
elseif ($_GET['module']=='link'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_link/link.php";
  }
}

// Bagian Menu Utama
elseif ($_GET['module']=='menuutama'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_menuutama/menuutama.php";
  }
}


// Bagian Sub Menu
elseif ($_GET['module']=='submenu'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_submenu/submenu.php";
  }
}


// Bagian Banner
elseif ($_GET['module']=='banner'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_banner/banner.php";
  }
}

// Bagian Password
elseif ($_GET['module']=='password'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_password/password.php";
  }
}

// Bagian Laporan
elseif ($_GET['module']=='laporan'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_laporan/laporan.php";
  }
}

// Bagian Laporan
elseif ($_GET['module']=='laporan2'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_laporan2/laporan2.php";
  }
}

// Bagian Search
elseif ($_GET['module']=='search'){
  if ($_SESSION['level']=='admin' or 'user'){
    include "modul/mod_search/search.php";
  }
}

// Bagian Selamat Datang
elseif ($_GET['module']=='welcome'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_welcome/welcome.php";
  }
}

// Bagian Sekilas Info
elseif ($_GET['module']=='sekilasinfo'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_sekilasinfo/sekilasinfo.php";
  }
}

// Bagian Poling
elseif ($_GET['module']=='poling'){
  if ($_SESSION['level']=='admin'){
    include "modul/mod_poling/poling.php";
  }
}

// Apabila modul tidak ditemukan
else{
  echo "<p><b>MODUL BELUM ADA ATAU BELUM LENGKAP</b></p>";
}
?>
